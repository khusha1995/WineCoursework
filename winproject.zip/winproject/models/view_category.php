<?php
class View_category  //get all category and display on page < this is used by the pages_controller.php page
{
	public $resule_cat;
    public function __construct() 
	{
		//get all category
     $db = Db::getInstance();
	 $query_category = "SELECT * FROM category";	
		$this->resule_cat=$db->prepare($query_category);
		$this->resule_cat->execute();
		$this->resule_cat = $this->resule_cat->fetchAll();
   }
}


class View_category_dsp_home
{
	public $resule_cat_dsp_home;
    public function __construct() 
	{
		//get all wine_category
       $db = Db::getInstance();
	   $query_category = "SELECT * FROM wine_category GROUP BY category_name";	
	   
		$this->resule_cat_dsp_home=$db->prepare($query_category);
		$this->resule_cat_dsp_home->execute();
		$this->resule_cat_dsp_home = $this->resule_cat_dsp_home->fetchAll();
   }
}
?>