<?php
session_start();
define("BASE_URL",'http://tengreenbottle.co.uk/winproject/winadmin/');		//takes you to the admin side
define("SITE_URL",'http://tengreenbottle.co.uk/winproject/');				//takes you to the customer side
define("CONTROLLER_POSTION",3);			//as this is admin, we split url into 3 segments, read the customer config. file. in the main folder
$actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
global $id;
$id =	explode('?',$actual_link);

require_once('lib/function.php');
?>