<?php
ob_start();
  class Db {
    private static $instance = NULL;

    private function __construct() {}

    private function __clone() {}

    public static function getInstance() {
      if (!isset(self::$instance)) {
        $pdo_options[PDO::ATTR_ERRMODE] = PDO::ERRMODE_EXCEPTION;
        self::$instance = new PDO('mysql:host=; dbname=', 'uk', '', $pdo_options);   //127.0.0.1 is the loopback Internet protocol //port 3307 for USBWebServer PhpMyAdmin
      }
      return self::$instance;
    }
  }
?>