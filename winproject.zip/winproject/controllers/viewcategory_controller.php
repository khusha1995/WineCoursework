<?php
  class ViewcategoryController 
  {
    public function viewcategory_controller() 
	{
  	  //view category controller page	
      require_once('views/pages/viewcategory_controller.php');
    }
	
	
    public function error() 
	{
      require_once('views/pages/error.php');
    }
  }
?>