  <div id="login-page">
	  	<div class="container">
	  	
		      <form class="form-login" action="<?php echo BASE_URL; ?>index.php" enctype="multipart/form-data" method="post">
                <input type="hidden" name="action" value="login" />
                <input type="hidden" name="controller" value="pages" />
                
		        <h2 class="form-login-heading">sign in </h2>
		        <div class="login-wrap">
		            <input type="text" class="form-control" name="user_id" placeholder="User ID" autofocus>
		            <br>
		            <input type="password" class="form-control" name="password" placeholder="Password">
		            <label class="checkbox">
		                <span class="pull-right">
		                    <a data-toggle="modal" href="login.html#myModal"> &nbsp;</a>
		
		                </span>
		            </label>
		            <input type="submit" class="btn btn-theme btn-block"   value="Submit">
		            <hr>
		        </div>
		
		      </form>	  	
	  	
	  	</div>
	  </div>   
  
