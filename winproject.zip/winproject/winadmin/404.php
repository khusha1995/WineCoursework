<?php
  require_once('connection.php');
  require_once('config.php');

 $REQUEST_URI=$_SERVER['REQUEST_URI'];
 $REQUEST_URI_ARRAY=explode('/',$REQUEST_URI);
 
 $controller = $REQUEST_URI_ARRAY[CONTROLLER_POSTION];
 $action_postion=CONTROLLER_POSTION+1;
 $action    = $REQUEST_URI_ARRAY[$action_postion];
 
 if($action=="logout")
 { 
	session_destroy();
	redirectto_other_page(BASE_URL);
 }
 
 if($action == NULL)
 { 
	$action='home'; 
 }
	userlogin_checking();		//created in the lib >function
								//used in index. page too
								
								
  require_once('views/layout.php');		//require the main page
?>