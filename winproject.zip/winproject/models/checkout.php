<?php
class Checkout_product_details
{
	//get user add to cart product details  
	public $get_query;
	public function __construct() {
		$db = Db::getInstance();
		if(isset($_SESSION['users'])){
		$get_query = "SELECT `shopping_basket`.*,shopping_basket.quantity_available_id AS qty,shopping_basket.total AS price,cost_of_wine.`cost_of_wine` AS cost_of_wine,wines.`wine_name` AS `name`, wines.`wineimage` AS item_image
                        FROM `shopping_basket`
                        INNER JOIN `cost_of_wine` 
                        ON `cost_of_wine`.`cost_of_wine_id`= `shopping_basket`.`cost_of_wine_id`
                        INNER JOIN `wines` 
                        ON `wines`.`unique_wine_code`= `shopping_basket`.`unique_wine_code`  where  shopping_basket.username = '".$_SESSION['users'][0]['username']."' and status='1'";

         
		 $this->get_query=$db->prepare($get_query);
		 $this->get_query->execute();
	 	$this->get_query = $this->get_query->fetchAll();
		}
		else
		{
			$this->get_query = $_SESSION['cart'];	
		}
	}
}





class Checkout 
{
		//insert check out form details
		public function __construct() 
		{
		    $db = Db::getInstance();
		
		
		if(isset($_POST['checkout_checkout_place_order']))
		{	
			if(isset($_SESSION['users'])){	
		
			$order_date_id=uniqid();
			$date = date('d-m-y');
/*ORER_DATE*/$order_date_qry="INSERT INTO order_date (`order_date_id`,`order_date`)VALUES('".$order_date_id."','".$date."')";            /*insert order date info. into the order_date table.*/
			$db->query($order_date_qry);
			
			$price_total_val=0;         /*initially total price is set to £0*/
			foreach($_POST['product_total'] as $price_total){
/*CALC TOTAL PRICE*/				
				$price_total_val = $price_total_val+$price_total;
			}
			$order_total_id=uniqid();
/*ORDER_TOTAL*/$order_total_qry="INSERT INTO order_total (`order_total_id`,`order_total`)VALUES('".$order_total_id."','".$price_total_val."')"; 
			$db->query($order_total_qry);
			
			$order_customer_id=uniqid();
			$customer_date = date('d-m-y');
/*CUST_ORDER*/$order_customer_qry="INSERT INTO customer_orders(`customer_order_id`,`order_date_id`,`order_total_id`,`invoice_date`)VALUES('".$order_customer_id."','".$order_date_id."','".$order_total_id."','".$customer_date."')"; 
			$db->query($order_customer_qry);
			
			$order_number=uniqid();
/*ORDERS*/  $order_qry="INSERT INTO orders(`order_number`,`username`,`order_date_id`,`order_total_id`,`customer_order_id`)VALUES('".$order_number."','".$_SESSION['users'][0]['username']."','".$order_date_id."','".$order_total_id."','".$order_customer_id."')"; 
			$db->query($order_qry);
			
			$order_history_id=uniqid();
/*ORDER_HIST*/$order_history_qry="INSERT INTO order_history(`history_id`,`shopping_basket_id`,`username`,`order_number`,`order_total_id`,`order_date_id`)VALUES('".$order_history_id."','".$_POST['basket_id']."','".$_SESSION['users'][0]['username']."','".$order_number."','".$order_total_id."','".$order_date_id."')"; 
			$db->query($order_history_qry);
			
			$querychange = "UPDATE shopping_basket SET status='0' WHERE username='".$_SESSION['users'][0]['username']."'";
			$db->query($querychange);
			}else{
/*IF USER HAS TO BE CREATED!*/
				$order_user_id=uniqid();
				$order_user_qry="INSERT INTO customer (`username`,`password`,`email_address`,`first_name`,`last_name`)VALUES('".$_POST['billing_first_name']."','".md5($_POST['billing_pwd'])."','".$_POST['billing_email']."','".$_POST['billing_first_name']."','".$_POST['billing_last_name']."')"; 
				$db->query($order_user_qry);
				
				
				$order_query = "select `username` from customer where username='".$_POST['billing_first_name']."'";
	 			$order_query=$db->prepare($order_query);
	 			$order_query->execute();
	 			$order_query = $order_query->fetchAll();
				
				
			$order_date_id=uniqid();
			$date = date('d-m-y');
			$order_date_qry="INSERT INTO order_date (`order_date_id`,`order_date`)VALUES('".$order_date_id."','".$date."')"; 
			$db->query($order_date_qry);
			
			$price_total_val=0;
			foreach($_POST['product_total'] as $price_total){
				
				$price_total_val = $price_total_val+$price_total;
			}
			$order_total_id=uniqid();
			$order_total_qry="INSERT INTO order_total (`order_total_id`,`order_total`)VALUES('".$order_total_id."','".$price_total_val."')"; 
			$db->query($order_total_qry);
			
			$order_customer_id=uniqid();
			$customer_date = date('d-m-y');
			$order_customer_qry="INSERT INTO customer_orders(`customer_order_id`,`order_date_id`,`order_total_id`,`invoice_date`)VALUES('".$order_customer_id."','".$order_date_id."','".$order_total_id."','".$customer_date."')"; 
			$db->query($order_customer_qry);
			
			$order_number=uniqid();
			$order_qry="INSERT INTO orders(`order_number`,`username`,`order_date_id`,`order_total_id`,`customer_order_id`)VALUES('".$order_number."','".$order_query[0]['username']."','".$order_date_id."','".$order_total_id."','".$order_customer_id."')"; 
			$db->query($order_qry);
			
			$order_history_id=uniqid();
			$order_history_qry="INSERT INTO order_history(`history_id`,`shopping_basket_id`,`username`,`order_number`,`order_total_id`,`order_date_id`)VALUES('".$order_history_id."','".$_POST['basket_id']."','".$order_query[0]['username']."','".$order_number."','".$order_total_id."','".$order_date_id."')"; 
			$db->query($order_history_qry);
				 
			session_unset($_SESSION["cart"]);
			}
			header('Location: '.BASE_URL.'pages/thankyou');
	
		}
		
		}
}
?>
