<DOCTYPE html>
<html>
<head>
 <title> Admin Page! </title>   
    <!--external css-->
    <link href="<?php echo BASE_URL; ?>views/assets/font-awesome/css/font-awesome.css" rel="stylesheet" />        
    <!-- Custom styles for this template -->
    <link href="<?php echo BASE_URL; ?>views/assets/css/style.css" rel="stylesheet">            <!--Empty-->
    <link href="<?php echo BASE_URL; ?>views/assets/css/Body.css" rel="stylesheet">             <!--Body of page-->
    <link href="<?php echo BASE_URL; ?>views/assets/css/Login.css" rel="stylesheet">            <!--Login-->
    <link href="<?php echo BASE_URL; ?>views/assets/css/MainPage.css" rel="stylesheet">         <!--MainPage-->
    <link href="<?php echo BASE_URL; ?>views/assets/css/Sidebar.css" rel="stylesheet">          <!--Sidebar-->
    
        <link href="<?php echo BASE_URL; ?>views/assets/css/style-responsive.css" rel="stylesheet">
</head>
  <body>
  <section id="container" >
   <?php if(is_userlogin()==1) require_once('sidebar.php'); ?>

    <?php require_once('routes.php'); ?>
   </section>
  <?php if(is_userlogin()==1) require_once('footer.php'); ?>
  </body>
</html>