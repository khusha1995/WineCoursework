<main id="main" class="site-main" role="main">

    <div class="view_cart">
        <br>
        <h1 class="h1-tag">Your Cart</h1>
        <form action="<?php echo BASE_URL; ?>index.php" method="post" method="post">
            <input type="hidden" name="action" value="view_cart"/>
            <input type="hidden" name="controller" value="pages"/>

            <table class="shop_table shop_table_responsive cart" cellspacing="0">
                <thead>
                <tr>
                    <th class="product-remove">&nbsp;</th>
                    <th class="product-thumbnail">&nbsp;</th>
                    <th class="product-name">Product</th>
                    <th class="product-price">Price</th>
                    <th class="product-quantity">Quantity</th>
                    <th class="product-subtotal">Total</th>
                </tr>
                </thead>

                <tbody>
                <?php

                if(isset($_SESSION['users'])){      /*if the user has logged in then get their cart data*/

                $cartDetail=GetCartDataWhenUserLogin();

                if($cartDetail){

                foreach ($cartDetail as $cart){ ?>

                <tr class="cart_item">
                    <td class="product-remove">
                        <a href="javascript:void(0);" class="remove remove-clart-item" title="Remove this item " data-product_id="<?php echo $cart['unique_wine_code']; ?>" data-product_sku="">×</a></td>
                    <td class="product-thumbnail"><img width="" height="180" src="<?php echo BASE_URL.'views/product_images/'.$cart['wineimage']; ?>"></td>
                    <td><?php echo $cart['wine_name']; ?></td>

                    <td class="product-price" data-title="Price">£<?php echo $cart['cost_of_wine']; ?></td>
					<input type="hidden" name="cost_of_wine[]" value="<?php echo $cart['cost_of_wine']; ?>">
                    <td class="product-quantity" data-title="Quantity"><input type="number" name="qty[]" min="1" step="1" value="<?php echo $cart['quantity_available_id']; ?>" required></td>

                    <td class="product-subtotal" data-title="Total">£<?php echo $cart['total']; ?></td>
                    <input type="hidden" name="unique_wine_code[]" value="<?php echo $cart['unique_wine_code']; ?>">
                    <input type="hidden" name="shopping_basket_id[]" value="<?php echo $cart['shopping_basket_id']; ?>">
                </tr>

                <?php } }} elseif(isset($_SESSION['cart'])){

                foreach ($_SESSION['cart'] as $cart){
            ?>
                    

                    <tr class="cart_item">
                        <td class="product-remove">             <!-- The remove button in the cart page -->
                        <a href="javascript:void(0);" class="remove remove-clart-item" title="Remove this item" data-product_id="<?php echo $cart['id']; ?>">×</a></td>
                        <td class="product-thumbnail"><img width="" height="180" src="<?php echo BASE_URL.'views/product_images/'.$cart['item_image']; ?>"></td>
                        <td><?php echo $cart['name']; ?></td>
                        <td class="product-price" data-title="Price">£<?php echo $cart['orginal_price']; ?></td>
                        <td class="product-quantity" data-title="Quantity"><input type="number" min="1" step="1" name="qty[]" value="<?php echo $cart['qty']; ?>" required></td>
                        <td class="product-subtotal" data-title="Total">£<?php echo $cart['price']; ?></td>
                        <input type="hidden" name="shopping_basket_id[]" value="<?php echo $cart['shopping_basket_id']; ?>">
                    </tr>
                <?php } } ?>
                <tr>
                </tr>
                </tbody>
            </table>

        <div class="cart-collaterals">
            <div class="wc-proceed-to-checkout text-right">
                <input type="submit" name="process_to_checkout" class="btn btn-theme btn-block" value="proceed to checkout">
            </div>
        </div>
    </form>
    </div>
    </div>
</main>