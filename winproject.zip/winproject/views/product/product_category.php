<div class="header_slide">
			<div class="header_bottom_left">				
				<div class="categories">
				  <ul>
				  	<h3>Product Categories</h3>	
				     <li><a href="<?php echo BASE_URL; ?>getredwine/getredwine/Red_Wine">Red Wine</a></li>
				      <li><a href="<?php echo BASE_URL; ?>getredwine/getredwine/White_Wine">White Wine</a></li>
				      <li><a href="<?php echo BASE_URL; ?>getredwine/getredwine/Rosa_Wine">Rose Wine</a></li>
				  </ul>
				</div>					
	  	     </div>
		   <div class="clear"></div>
</div>

<div class="main">
    <div class="content">
    
    <?php $new_array = array_filter($View_category_dsp_detailpage->resule_cat_dsp_detailpage);  ?>
    	<div class="content_top">
    		<div class="heading">
				<h3><?php $slug=str_replace("_"," ",$new_array[0]['category_name']);  echo $slug;?></h3> <!--get the category name and create a unique string out of it using $slug variable-->
    		</div>
    		<div class="clear"></div>
            <div class="section group">
				<?php  $cat_id=$new_array[0]['category_name']; display_product($cat_id); ?>         <!--display products accordingly-->
			</div>
    	</div>
 	</div>
</div>