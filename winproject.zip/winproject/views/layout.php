<DOCTYPE html>
<html>
<head>
<title>10 Green Bottles Website</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

<link href="<?php echo BASE_URL; ?>views/css/style.css" rel="stylesheet" type="text/css" media="all"/>  <!--Responsiveness for page-->
<link rel="stylesheet" href="<?php echo BASE_URL; ?>views/css/detailedview.css">                        <!--Detailed view of products-->
<link rel="stylesheet" href="<?php echo BASE_URL; ?>views/css/styles.css">                              <!--Checkout Page-->
<link rel="stylesheet" href="<?php echo BASE_URL; ?>views/css/About.css">                               <!--About Page-->
<link rel="stylesheet" href="<?php echo BASE_URL; ?>views/css/Cart.css">                                <!--Cart Page-->
<link rel="stylesheet" href="<?php echo BASE_URL; ?>views/css/Categories.css">                          <!--Categories Page-->
<link rel="stylesheet" href="<?php echo BASE_URL; ?>views/css/ContactForm.css">                         <!--ContactForm Page-->
<link rel="stylesheet" href="<?php echo BASE_URL; ?>views/css/contact_us.css">                         <!--ContactForm Email Design-->
<link rel="stylesheet" href="<?php echo BASE_URL; ?>views/css/footer.css">                              <!--Footer section-->
<link rel="stylesheet" href="<?php echo BASE_URL; ?>views/css/MainPageProducts.css">                    <!--MainPage Products Page-->
<link rel="stylesheet" href="<?php echo BASE_URL; ?>views/css/MenuSearch.css">                          <!--Menu & SearchBar Section-->
<link rel="stylesheet" href="<?php echo BASE_URL; ?>views/css/ProdInfoPage.css">                        <!--Product Information Page-->
<link rel="stylesheet" href="<?php echo BASE_URL; ?>views/css/ProdReview.css">                          <!--Product Review Page-->
<link rel="stylesheet" href="<?php echo BASE_URL; ?>views/css/RegLogin.css">                            <!--Registration & Login-->
<link rel="stylesheet" href="<?php echo BASE_URL; ?>views/css/account.css">                             <!--Account-->


<script type="text/javascript" src="<?php echo BASE_URL; ?>views/js/jquery-1.7.2.min.js"></script> 
<script src="<?php echo BASE_URL; ?>views/js/MyCustomJs.js?54"></script>



</head>
  <body>
  <div class="wrap">

   <?php
   require_once('lib/function.php');
   require_once('header.php'); ?>

    <?php require_once('routes.php'); ?>
   </div>
  <?php require_once('footer.php'); ?>
  </body>
</html>