<?php
class Insert_registor
{
	public function __construct()
	{
		//insert user register details from the form into the dB table = Customer, once registered redirect back to the login page
		if(isset($_POST['registor']))
		{
			$db = Db::getInstance();
			$qry="INSERT INTO customer (`username`,`password`,`email_address`,`date_of_birth`,`title`,`first_name`,`last_name`)VALUES('".$_POST['user_name']."','".md5($_POST['pwd'])."','".$_POST['email']."','".$_POST['dob']."','".$_POST['title']."','".$_POST['fname']."','".$_POST['lname']."')"; 
			$db->query($qry); 
			session_start();
			$_SESSION["registor_success"] = "true";
			//take user back to login page once registered
			header("Location:".BASE_URL."pages/login");
		}
	}
}