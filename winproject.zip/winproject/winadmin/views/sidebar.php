 <aside>
          <div id="sidebar"  class="nav-collapse ">
              <ul class="sidebar-menu" id="nav-accordion">
             
                  <li class="sub-menu">
                      <a class="<?php if($controller=='' || $action=='home' || $controller=='product'){?>active<?php } ?>" href="javascript:;" >
                          <i class="fa fa-th"></i>
                          <span>Wine Options</span>
                      </a>
                      <ul class="sub">
                          <li <?php if($controller=='' || $controller=='product'){?>active<?php } ?>><a  href="<?php echo BASE_URL; ?>">View All Wines</a></li>
                          <li><a  href="<?php echo BASE_URL; ?>product/add_form">Add A Wine</a></li>
                      </ul>
                  </li>
                  <li class="sub-menu">
                     <li><a  href="<?php echo BASE_URL; ?>pages/logout">Logout!</a></li>
                  </li>
                  
                  

              </ul>
          </div>
      </aside>
