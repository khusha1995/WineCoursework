<?php
class GetrosawineController 
{
	public function getrosawine() 
	{
		//load model page
	  require_once('models/winedata.php');
	  
	  //get detail of product category rose wine
	  $View_category_dsp_detailpage= new View_category_dsp_detailpage();
	  
	  //user view > detail of product category
	  require_once('views/product/product_category.php');
	}
}
?>
