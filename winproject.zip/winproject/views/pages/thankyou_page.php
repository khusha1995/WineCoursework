
	<p>Thank You for the order, we appreciate your business!</p>
		<p>We Hope To See You Again Soon!</p>
		<br><br><br><br><br>