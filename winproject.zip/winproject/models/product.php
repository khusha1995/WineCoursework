<?php
class Product 
{
    public $slug;
    public function __construct() 
	{
		//get product details 
		
		$db = Db::getInstance();
		//explode_url = split the path into its path segments
		global $expload_url;        /*break url into segments*/
		$slug_name=CONTROLLER_POSTION+3;
		$product_query = " 
		select unique_wine_code,slug,wine_name,description,wineimage,cost_of_wine
			from wines
			LEFT OUTER JOIN cost_of_wine
            on wines.cost_of_wine_id=cost_of_wine.cost_of_wine_id where wines.slug='".$expload_url[$slug_name]."'";
		$this->slug=$db->prepare($product_query);
	 	$this->slug->execute();
	 	$this->slug = $this->slug->fetchAll();
    }
}

//view the detailed page for the product
class View_category_dsp_detailpage
{
	//get category name
	public $resule_cat_dsp_detailpage;
    public function __construct() 
	{
       $db = Db::getInstance();
	   global $expload_url;
		$slug_name=CONTROLLER_POSTION+3; 
	   $query_category = "SELECT * FROM category where slug='".$expload_url[$slug_name]."'";	
	 $this->resule_cat_dsp_detailpage=$db->prepare($query_category);
	 $this->resule_cat_dsp_detailpage->execute();
	 $this->resule_cat_dsp_detailpage = $this->resule_cat_dsp_detailpage->fetchAll();
    }
}

//view any reviews that the product might have
class View_review
{
	//get user review
	public $product_review;
	public function __construct() 
	{
		 $db = Db::getInstance();
		 $product_review = "SELECT * FROM product_review";
		 $this->product_review=$db->prepare($product_review);
		 $this->product_review->execute();
		 $this->product_review = $this->product_review->fetchAll();
	}
}
?>