<div class="main">
    <div class="content">
    	<div class="section group">
        <div class="col_1_of_3 span_1_of_3">
  <div id="login-page">
	  	<div class="container">
		      <form class="form-login" action="<?php echo BASE_URL; ?>index.php" enctype="multipart/form-data" method="post">
                <input type="hidden" name="action" value="insert_registor" />
                <input type="hidden" name="controller" value="pages" />
                
		        <h2 class="form-login-heading" style="text-align:center;">Register: </h2>
		        <div class="login-wrap">
                		<p><label>UserName: </label></p>
						<p id="user_name_class"><input type="text" class="form-control" id="user_name" name="user_name" placeholder="" autofocus> <br></p>
                    
						<p><label>Password: </label></p>
						<p id="pwd_class"><input type="password" class="form-control" id="pwd" name="pwd" placeholder=""> <br></p>
		            
						<p><label>Email Address: </label></p>
						<p id="email_class"><input type="text" class="form-control" id="email" name="email"> <br></p>
                    
                    
						<p><label>Date Of Birth: </label></p>
						<p id="dob_class"><input type="date" class="form-control" id="dob" name="dob"> <br></p>
                    
                    
						<p><label>Title: </label></p>
						<p id="title_class"><input type="text" class="form-control" id="title" name="title"> <br></p>
                    
                    
						<p><label>First Name: </label></p>
						<p id="fname_class"><input type="text" class="form-control" id="fname" name="fname"> <br></p>
                    
						<p><label>Last Name: </label></p>
						<p id="lname_class"><input type="text" class="form-control" id="lname" name="lname"> <br></p>
                    
						<p><input type="submit" class="btn btn-theme btn-block" id="registor" name="registor" value="REGISTER!"></p>
		        </div>
		      </form>	  	
	  	</div>
   </div>   
  </div>
	  </div>
      </div>
</div>


<!--ERROR CHECKING FOR USER ERRORS AND STUFF-->

<script type="text/javascript">
    $(document).ready(function(){
        $("#registor").click(function(e){
			 var user_name =jQuery("#user_name").val();
			 var pwd =jQuery("#pwd").val(); 
			 var email =jQuery("#email").val(); 
			 var dob =jQuery("#dob").val(); 
			 var title =jQuery("#title").val(); 
			 var fname =jQuery("#fname").val(); 
			 var lname =jQuery("#lname").val();
			  var flg=0;
			 	 if(user_name == ""){
					jQuery(".user_name-span").html("");
					jQuery("#user_name_class").append("<span class='user_name-span'> Please Enter A Username</span>");
					flg=1;
            	}else{
                	jQuery(".user_name-span").html("");
            	}
				if(pwd == ""){
					jQuery(".pwd_class-span").html("");
					jQuery("#pwd_class").append("<span class='pwd_class-span'> Please Enter A Password</span>");
					flg=1;
            	}else{
                	jQuery(".pwd_class-span").html("");
            	}
				if(email == ""){
					jQuery(".email_class-span").html("");
					jQuery("#email_class").append("<span class='email_class-span'> Please Enter A Email Address</span>");
					flg=1;
            	}else{
                	jQuery(".email_class-span").html("");
            	}
				if(dob == ""){
					jQuery(".dob_class-span").html("");
					jQuery("#dob_class").append("<span class='dob_class-span'> Please Enter Your Date Of Birth</span>");
					flg=1;
            	}else{
                	jQuery(".dob_class-span").html("");
            	}
				if(title == ""){
					jQuery(".title_class-span").html("");
					jQuery("#title_class").append("<span class='title_class-span'> Please Enter Your Title</span>");
					flg=1;
            	}else{
                	jQuery(".title_class-span").html("");
            	}
				if(fname == ""){
					jQuery(".fname_class-span").html("");
					jQuery("#fname_class").append("<span class='fname_class-span'> Please Enter Your First Name</span>");
					flg=1;
            	}else{
                	jQuery(".fname_class-span").html("");
            	}
				if(lname == ""){
					jQuery(".lname_class-span").html("");
					jQuery("#lname_class").append("<span class='lname_class-span'> Please Enter Your Last Name</span>");
					flg=1;
            	}else{
                	jQuery(".lname_class-span").html("");
            	}
			if(flg==1){
                e.preventDefault();
            }  
		});
	});
</script>   
