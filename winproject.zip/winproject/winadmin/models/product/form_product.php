<?php
class Form_product{

    public $edit_product_data;
	public $edit_category_data;
	public $action_data;
	public $lable_data;
  
    public function __construct(){
		global $id;
		
       $db = Db::getInstance();
	 $this->action_data="insert_product";
	  $this->lable_data="Add";
	  if(isset($id[1]) && $id[1] != NULL){
		  //show all wines in dB and relevent info for that wine.
	    $query_product_edit="SELECT unique_wine_code,wine_name,description,wine_indicator, wineimage, quantity_available, cost_of_wine 
FROM wines 
LEFT OUTER  JOIN quantity_available ON wines.quantity_available_id = quantity_available.quantity_available_id
LEFT OUTER  JOIN cost_of_wine ON wines.cost_of_wine_id = cost_of_wine.cost_of_wine_id  
WHERE wines.unique_wine_code=".$id[1];
		
         $this->edit_product_data=$db->prepare($query_product_edit);
	 	 $this->edit_product_data->execute();
	     $this->edit_product_data = $this->edit_product_data->fetchAll();
		 
		 $category_edit="SELECT * from wine_category where unique_wine_code='".$id[1]."'";
		 $this->edit_category_data=$db->prepare($category_edit);
	 	 $this->edit_category_data->execute();
	     $this->edit_category_data = $this->edit_category_data->fetchAll();
		 		 
		$this->action_data="update_product";
		$this->lable_data="update";
	 }
	
   }
}
  
?>