<?php
function display_product($slug)
{
	//select category name with product id and get all product data 
	$db = Db::getInstance();
	$product_id="SELECT unique_wine_code FROM `wine_category` WHERE category_name='".$slug."'";
	$resule_cat=$db->prepare($product_id);
	$resule_cat->execute();
	$resule_cat = $resule_cat->fetchAll();
	 
	 foreach($resule_cat as $product_id)
	 {
		 //create a query in which wines and cost of wine are selected with id
		 	$product_query = "select *
			from wines
			LEFT OUTER JOIN cost_of_wine
            on wines.cost_of_wine_id=cost_of_wine.cost_of_wine_id where wines.unique_wine_code=".$product_id['unique_wine_code']; 
			
			
			$resule_cat1=$db->prepare($product_query);
			 $resule_cat1->execute();
			 $resule_cat1 = $resule_cat1->fetchAll();
			                                                /*DISPLAY ALL WINES WITH ADD BUTTON*/
			 foreach($resule_cat1 as $product_data){ ?>
				<div class="grid_1_of_4 images_1_of_4">
					 <a href="<?php echo BASE_URL; ?>product/<?php echo $product_data['slug']; ?>">
                         <img src="<?php echo BASE_URL; ?>views/product_images/<?php echo $product_data['wineimage']; ?>" alt=""></a>		<!--REMINDER: MAKE SURE IMAGE DIMENSION = 212 x 212 -->
					 <h2><?php $slug=str_replace("_"," ",$product_data['wine_name']); echo $slug; ?></h2>
					<div class="price-details">
				       <div class="price-number">
							<p><span class="pounds">£<?php echo $product_data['cost_of_wine']; ?></span></p>
					    </div>
					       		<div class="add-cart">								
									<h4><a data-unique_wine_code="<?php echo $product_data['unique_wine_code']; ?>" class="add-product" href="<?php echo BASE_URL; ?>product/<?php echo $product_data['wine_name']; ?>">Add</a></h4>
							     </div>
							 <div class="clear"></div>
					</div>
				</div>
			 <?php }
	}
	
}

function GetCartDataWhenUserLogin()
{
	//get cart data when user logs in, a query is made where all items from shopping_basket are selected and joined
	//INNER JOIN selects records that have matching values in both tables
    require_once('connection.php');
    require_once('config.php');
    $db = Db::getInstance();

    if(isset($_SESSION['users']))
	{
            $get_query = "  SELECT `shopping_basket`.*,cost_of_wine.`cost_of_wine` AS cost_of_wine,
                            wines.`wine_name` AS wine_name,wines.`wineimage` AS wineimage
                            FROM `shopping_basket`
                            INNER JOIN `cost_of_wine` 
                            ON `cost_of_wine`.`cost_of_wine_id`= `shopping_basket`.`cost_of_wine_id`
                            INNER JOIN `wines` 
                            ON `wines`.`unique_wine_code`= `shopping_basket`.`unique_wine_code`
                            where shopping_basket.status = 1 AND username='".$_SESSION['users'][0]['username']."'";
            $get_query=$db->prepare($get_query);
            $get_query->execute();
            $get_query = $get_query->fetchAll();
			
            return $get_query;
    }
}

 if(isset($_POST['cart']))
 {
     $success = 0;
     require_once('../connection.php');
     require_once('../config.php');

     $db = Db::getInstance();
     $product_query = " 
        select wines.unique_wine_code,wines.wine_name,wines.wineimage,cost_of_wine.cost_of_wine,cost_of_wine.cost_of_wine_id
        from wines 
        inner join cost_of_wine 
        on wines.cost_of_wine_id=cost_of_wine.cost_of_wine_id 
        where unique_wine_code='".$_POST['unique_wine_code']."'";
     $slug=$db->prepare($product_query);
     $slug->execute();
     $slug = $slug->fetchAll();
		//if the session is enabled but none current exist then start one.
     if (session_status() == PHP_SESSION_NONE) {
         session_start();
     }
     $flg=0;

     $shopping_basket_id        = uniqid('bkt');
     $username                  = isset($_SESSION['users']) ? $_SESSION['users'][0]['username'] : '';
	//create an array for the cart
     $cart= array(
         "id"                   => $slug[0]['unique_wine_code'],
         "qty"                  => 1,                                 /*ensure quantity is ATLEAST 1*/
         "orginal_price"        => $slug[0]['cost_of_wine'],
         "price"                => $slug[0]['cost_of_wine'],
         "name"                 => $slug[0]['wine_name'],
         "item_image"           => $slug[0]['wineimage'],
         "shopping_basket_id"   => $shopping_basket_id,
         'unique_wine_code'     => $slug[0]['unique_wine_code'],
         'cost_of_wine_id'      => $slug[0]['cost_of_wine_id'],
     );

     if(empty($_SESSION['cart']))
	 {
			//if the user session is set
             if(isset($_SESSION['users']))
			 {
                 $get_query = "select * from shopping_basket where shopping_basket.status = 1 AND unique_wine_code='".$_POST['unique_wine_code']."' AND username = '$username'";
                 $get_query=$db->prepare($get_query);
                 $get_query->execute();
                 $get_query = $get_query->fetchAll();
				//if the cart is empty then insert into the shopping_Basket table
                 if(empty($get_query))
				 {
                     $sql = "INSERT INTO shopping_basket (shopping_basket_id, unique_wine_code, username,quantity_available_id,cost_of_wine_id,total)
                             VALUES ('".$cart['shopping_basket_id']."',".$cart['unique_wine_code'].",'$username','".$cart['qty']."','".$cart['cost_of_wine_id']."',".$cart['price'].")";
                 }else
				 {
                     $qty   = $cart['qty']+$get_query[0]['quantity_available_id'];
                     $total = $cart['price']+$get_query[0]['total'];

                    $sql = "Update shopping_basket set quantity_available_id='".$qty."',total='".$total."'
                            WHERE shopping_basket.status = 1 AND unique_wine_code=".$get_query[0]['unique_wine_code']." AND username = '$username' AND cost_of_wine_id = '".$get_query[0]['cost_of_wine_id']."'";
                 }

                 if($db->exec($sql))
				 {
                        $get_query = "SELECT `shopping_basket`.*,shopping_basket.quantity_available_id as qty,shopping_basket.total as price,cost_of_wine.`cost_of_wine` AS cost_of_wine,wines.`wine_name` AS `name`, wines.`wineimage` AS item_image
                        FROM `shopping_basket`
                        INNER JOIN `cost_of_wine` 
                        ON `cost_of_wine`.`cost_of_wine_id`= `shopping_basket`.`cost_of_wine_id`
                        INNER JOIN `wines` 
                        ON `wines`.`unique_wine_code`= `shopping_basket`.`unique_wine_code`  where shopping_basket.status = 1 AND shopping_basket.username = '$username'";

                     $get_query=$db->prepare($get_query);
                     $get_query->execute();
                     $get_query = $get_query->fetchAll(PDO::FETCH_ASSOC);
                     echo json_encode($get_query);
                     die;

                 }else
				 {
                     die("error");
                 }
             }else
			 {
                 $_SESSION['cart'][0]=$cart;
                 echo json_encode($_SESSION['cart']);
                 die;
             }
     }else
	 {
         $flg=2; $i=0;
         if(isset($_SESSION['users'])){
                 $get_query = "select * from shopping_basket where shopping_basket.status = 1 AND unique_wine_code='".$_POST['unique_wine_code']."' AND username = '$username'";
                 $get_query = $db->prepare($get_query);
                 $get_query->execute();
                 $get_query = $get_query->fetchAll();

                 if(empty($get_query))
				 {

                     $sql   = "INSERT INTO shopping_basket (shopping_basket_id, unique_wine_code, username,quantity_available_id,cost_of_wine_id,total)
                                VALUES ('".$cart['shopping_basket_id']."',".$cart['unique_wine_code'].",'$username','".$cart['qty']."','".$cart['cost_of_wine_id']."',".$cart['price'].")";
                 }else
				 {
                     $qty   = $cart['qty']+$get_query[0]['quantity_available_id'];
                     $total = $cart['price']+$get_query[0]['total'];
                     $sql   = "Update shopping_basket set quantity_available_id='".$qty."',total='".$total."'
                         WHERE shopping_basket.status = 1 AND unique_wine_code=".$cart['unique_wine_code']." AND username = '$username' AND cost_of_wine_id = '".$cart['cost_of_wine_id']."'";
                 }

                 if($db->exec($sql))
				 {
                     $get_query = "SELECT `shopping_basket`.*,shopping_basket.quantity_available_id as qty,shopping_basket.total as price,cost_of_wine.`cost_of_wine` AS cost_of_wine,wines.`wine_name` AS `name`, wines.`wineimage` AS item_image
                        FROM `shopping_basket`
                        INNER JOIN `cost_of_wine` 
                        ON `cost_of_wine`.`cost_of_wine_id`= `shopping_basket`.`cost_of_wine_id`
                        INNER JOIN `wines` 
                        ON `wines`.`unique_wine_code`= `shopping_basket`.`unique_wine_code`  where shopping_basket.status = 1 AND shopping_basket.username = '$username'";

                     $get_query=$db->prepare($get_query);
                     $get_query->execute();
                     $get_query = $get_query->fetchAll(PDO::FETCH_ASSOC);

                     echo json_encode($get_query);
                     die;
                 }

         }else      //update quantity and price
		 {
             foreach($_SESSION['cart'] as $cart_row)
			 {
                 if($cart_row['id'] === $_POST['unique_wine_code'])
				 {
                     $_SESSION['cart'][$i]['qty']+=1;
                     $_SESSION['cart'][$i]['price'] = (double)($slug[0]['cost_of_wine']*$_SESSION['cart'][$i]['qty']);
                     $flg = 1;
                 }
                 $i++;
             }

             if($flg!=1)
			 {
                 array_push($_SESSION['cart'],$cart);
             }
                 echo json_encode($_SESSION['cart']); //json_encode will print: e.g. line 174. {":id":"qty":"cost":"price"} etc. for all variable $cart's
                 die;

         }

     }
 }

 /*REMOVE ITEM FROM THE CART!*/
 if(isset($_POST['cart_item_remove']))
 {
	 //create a session if one doesn't exist
     if (session_status() == PHP_SESSION_NONE) 
	 {
         session_start();
     }
     if(isset($_SESSION['users']))
	 {
         require_once('../connection.php');
         require_once('../config.php');

         $db = Db::getInstance();
         $delete_query = "DELETE FROM shopping_basket WHERE shopping_basket.status = 1 AND unique_wine_code='".$_POST['cart_item_remove']."' AND username = '".$_SESSION['users'][0]['username']."'";
         $delete_query = $db->prepare($delete_query);
         $delete_query->execute();
         $get_query = "SELECT `shopping_basket`.*,shopping_basket.quantity_available_id AS qty,shopping_basket.total AS price,cost_of_wine.`cost_of_wine` AS cost_of_wine,wines.`wine_name` AS `name`, wines.`wineimage` AS item_image
                        FROM `shopping_basket`
                        INNER JOIN `cost_of_wine` 
                        ON `cost_of_wine`.`cost_of_wine_id`= `shopping_basket`.`cost_of_wine_id`
                        INNER JOIN `wines` 
                        ON `wines`.`unique_wine_code`= `shopping_basket`.`unique_wine_code`  where shopping_basket.status = 1 AND shopping_basket.username = '".$_SESSION['users'][0]['username']."'";

         $get_query=$db->prepare($get_query);
         $get_query->execute();
         $get_query = $get_query->fetchAll(PDO::FETCH_ASSOC);
         echo json_encode(array("success" => 'true','data' => $get_query));

     }else
	 {
         $session_refresh = array();

         foreach($_SESSION['cart'] as $cart_row)
		 {
             if($cart_row['id'] != $_POST['cart_item_remove'])
			 {
                 $session_refresh[] = $cart_row;            /*if user removes item from cart then refresh the session to show updates values*/
             }
         }
         if(!empty($session_refresh))
		 {
             unset($_SESSION['cart']);
             $_SESSION['cart'] = $session_refresh;
             echo json_encode(array("success" => 'true','data' => $session_refresh));
         }else
		 {
             echo json_encode(array("success" => 'false','data' => ''));
         }
     }
 }