<?php

  function call($controller, $action) {
	 
    require_once('controllers/' . $controller . '_controller.php');
	//echo $controller; echo $action; exit;
    switch($controller) {
      case 'pages':	  
	  	
      break;
      case 'product':
        // we need the model to query the database later in the controller
        require_once('models/product.php');
      break;
	  case 'category':
        // we need the model to query the database later in the controller
        require_once('models/product.php');        
      break;
	  
    }
	$controller=ucfirst($controller);
	$controller_class=$controller.'Controller';
	$controller = new $controller_class();
    $controller->{ $action }();
  }

  // we're adding an entry for the new controller and its actions
  $controllers = array('pages' => ['home','about','contact','login','registor',
                                    'insert_registor','error','logout','AddToCart','review','view_cart','checkout','thankyou','account','change_pwd','account_detail','contact_detail','search'],
                        'product' => ['view'],
                       'category' => ['view'],
					   'getredwine' => ['getredwine'],
					   'getwhitewine' => ['getwhitewine'],
					   'getrosawine' => ['getrosawine'],
                       'posts' => ['index', 'show']);

  if (array_key_exists($controller, $controllers)) {
   
      call($controller, $action);   
  } else {
    call('pages', 'error');
  }
?>