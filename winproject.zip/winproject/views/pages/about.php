<div class="main">
    <div class="content">
    	<div class="section group">
				<div class="col_1_of_3 span_1_of_3">
					<h3>Who Are We?</h3>
					<img src="<?php echo BASE_URL; ?>views/images/wineshop.jpg" alt="Picture of the wine shop - inside view">
					<p>We are a proud family that have been trained in the art of Wine since 1911, we have recently moved online to make buying wine more easier for our customers. We stock all of the finest wine around and at a competative rate that cannot be matched!</p>
				</div>
				<div class="col span_1_of_3">
					<div class="contact_info">
    	 				<h3>Where Are We?</h3>
					    	  <div class="map"> <!--Google maps code - using Google maps -->
							   	    <iframe src="https://www.google.com/maps/embed?pb=!1m0!3m2!1sen!2suk!4v1490444973584!6m8!1m7!1s_8vOO9WU5H_2xEQyYV0YIw!2m2!1d51.78609127935296!2d-0.7389468771791314!3f82.40115550739282!4f-15.20315460687435!5f0.7820865974627469" width="400" height="300" frameborder="0" style="border:0" allowfullscreen></iframe>
							  </div>
      				</div>
      			    <div class="company_address">
						    	<p>25 Halton Village</p>
						   		<p>Aylesburg</p>
						   		<p>London</p>
								<p>HP22 5NS</p>
								<p>Phone: 03837629198</p>
				    </div>
				</div>
		</div>
    </div>
 </div>