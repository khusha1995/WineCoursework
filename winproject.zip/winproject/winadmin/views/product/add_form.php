      <section id="main-content">
          <section class="wrapper">
          	
				<!-- row -->

              <div class="row mt">
                  <div class="col-md-12">
                      <div class="content-panel">
                  		
                      <form class="" action="<?php echo BASE_URL; ?>index.php" enctype="multipart/form-data" method="post">
                      		<input type="hidden" name="action" value="<?php echo $Form_product->action_data; ?>" />
                			<input type="hidden" name="controller" value="product" />
                            <input type="hidden" name="product_id" value="<?php echo $Form_product->edit_product_data[0][0];?>" />
                          <table class="table table-striped table-advance table-hover">
	                  	  	  <h4> Wines </h4>
	                  	  	  <hr>
                              <thead>
                              <tr>
                                 
                                  <td>
                                  Wine Name:<br />
                                  <input value="<?php echo $Form_product->edit_product_data[0]['wine_name']; ?>" type="text" name="wine_name"/></td>
                              </tr>                           
                              <tr>
                                  <td>
                                  Description:<br />
                                  <textarea rows="5"  cols="50" name="description" ><?php echo $Form_product->edit_product_data[0]['description']; ?></textarea></td>
                              </tr>
                              <tr>
                                 
                                  <td>
                                  Image<br/>
                                  <?php if($Form_product->edit_product_data[0]['wineimage'] != NULL){ ?>
                                   <img src="<?php  echo SITE_URL."views/product_images/".$Form_product->edit_product_data[0]['wineimage']; ?>" width="150px" height="150px" /> <br />
                                   <?php } ?>
                                   <input type="file" name="p_images" />
                                  </td>
                              </tr>
                               
                              <tr>
                                  <td>
                                  Quantity:<br />
                                <input value="<?php echo $Form_product->edit_product_data[0]['quantity_available']; ?>" type="number" name="p_quantity"/></td>
                              </tr>
                               <tr>
                                  <td>
                                  Cost of Wine:<br />
                                <input value="<?php echo $Form_product->edit_product_data[0]['cost_of_wine']; ?>" type="text" name="cost_of_wine"/></td>
                              </tr>
        						<tr>
                                	<td>Wine Indicator:<br />
                                    <select name="wine_indicator">
                                    	<option value="">Select</option>
                                        <option <?php if($Form_product->edit_product_data[0]['wine_indicator'] == 'Light'){ ?>selected="selected"<?php } ?> value="Light">Light</option>
                                        <option <?php if($Form_product->edit_product_data[0]['wine_indicator'] == 'Full-bodied'){ ?>selected="selected"<?php } ?> value="Full-bodied">Full-bodied</option>
                                        <option <?php if($Form_product->edit_product_data[0]['wine_indicator'] == 'Dry'){ ?>selected="selected"<?php } ?> value="Dry">Dry</option>
                                        <option <?php if($Form_product->edit_product_data[0]['wine_indicator'] == 'sweet'){ ?>selected="selected"<?php } ?> value="sweet">sweet</option>
                                        <option <?php if($Form_product->edit_product_data[0]['wine_indicator'] == 'Refreshing'){ ?>selected="selected"<?php } ?> value="Refreshing">Refreshing</option>
										<option <?php if($Form_product->edit_product_data[0]['wine_indicator'] == 'Fruity'){ ?>selected="selected"<?php } ?> value="Fruity">Fruity</option>		
                                    </select>
                                    </td>
                                </tr>
                                <tr>
                                	<td>Category Name:<br />
                                    <select name="category_name">
                                    	<option value="">Select</option>
                                        <option <?php if($Form_product->edit_category_data[0]['category_name'] == 'Red_Wine'){ ?>selected="selected"<?php } ?>  value="Red_Wine">Red Wine</option>
                                        <option <?php if($Form_product->edit_category_data[0]['category_name'] == 'White_Wine'){ ?>selected="selected"<?php } ?> value="White_Wine">White Wine</option>
                                        <option <?php if($Form_product->edit_category_data[0]['category_name'] == 'Rosa_Wine'){ ?>selected="selected"<?php } ?> value="Rosa_Wine">Rose Wine</option>
                                    </select>
                                    </td>
                                </tr>	
                              <tr> 
                                  <td><input type="submit" name="submit" value="<?php echo $Form_product->lable_data; ?>"/></td>
                              </tr>
                              </thead>
                          </table>
                      </form>    
                      </div>
                  </div>
              </div>

		</section>
      </section>
     
  </section>
