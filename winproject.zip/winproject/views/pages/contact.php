<div class="main">
    <div class="content">
    	<div class="section group">
				<div class="col span_2_of_3">
				  <div class="contact-form">
                 			<?php 
								//session_start();
								if(isset($_SESSION["contact_mail"]) == "true"){
							?>
     <p style="color: green;">Successfully Sent</p> <!--WHEN USER SUCCESSFULLY SENDS EMAIL -->
                            	
                            <?php session_unset($_SESSION["contact_mail"]); } ?>
				  	<h2>Need to tell us something? - Contact Us!</h2>
					    <form method="post" action="<?php echo BASE_URL; ?>index.php">
                        	<input type="hidden" name="action" value="contact_detail" />
        					<input type="hidden" name="controller" value="pages" />
        					<br><br><br>
					    	<div>
						    	<span><label>Your Full Name: </label></span>
						    	<span><input name="user" type="text" class="textbox" ></span>
						    </div>
						    <div>
						    	<span><label>E-mail Address: </label></span>
						    	<span><input name="email" class="email" type="email"></span>
						    </div>
						    <div>
						    	<span><label>Subject: (Please be as specific as possible)</label></span>
						    	<span><textarea name="usermessage"> </textarea></span>
						    </div>
						   <div>
						   		<span><input type="submit" value="Submit" name="contact" class="myButton"></span>
						  </div>
					    </form>
				  </div>
  				</div>
	    </div>		
    </div> 
</div>