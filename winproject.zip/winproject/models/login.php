<?php
  class Login 
  {
    public $id;
   

    public function __construct() 
	{
		//admin login page
		//if there is no admin currently logged in then do the following
		 if(isset($_POST['user_id']) && $_POST['user_id'] != NULL && isset($_POST['password']) && $_POST['password'] != NULL)
		 {
			 //set (userrow to 0) initially, then select from login page the details for admin
			 $db = Db::getInstance();
			 $userrow=0;
			 $query_user_login = "SELECT * FROM admin_details WHERE `user_name`='".$_POST['user_id']."' AND `password`='".md5($_POST['password'])."'";
			 //set (userrow to 1) now, then loop over the username, email and id to create session
			 foreach($db->query($query_user_login) as $userdata)
			 {
				$userrow=1;
				 $_SESSION['user_name']=$userdata['user_name'];
				 $_SESSION['email_id']=$userdata['email_id'];
				 $_SESSION['id']=$userdata['id'];
				
				 
			 }
			
			//if user already logged in (userrow=1) then redirect to the homepage only else give an error message
			 if($userrow==1){
				  
				 redirectto_other_page(BASE_URL);
				
				 
			 }else{
                set_error_message("The Login Details are wrong!");
			 }
		 }
    }
  }
  
   //instance in winadmin/model/login too
  $LOGIN =  new Login();
?>