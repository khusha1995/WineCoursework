 <script src="<?php echo BASE_URL; ?>views/assets/js/jquery.js"></script>

    <!--common script for all pages-->
    <script src="<?php echo BASE_URL; ?>views/assets/js/common-scripts.js"></script>
	<script type="text/javascript" src="<?php echo BASE_URL; ?>views/assets/js/jquery.bootpag.min.js"></script>