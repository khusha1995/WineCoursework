<?php
  class ProductController 
  {
    public function add_form() 
	{
     $Form_product = new Form_product();
      require_once('views/product/add_form.php');
    }
	
	public function insert_product()
	{
		require_once('models/product/insert_product.php');	
		 $insert_product = new insert_product();
	}

	public function update_product()
	{
		require_once('models/product/update_product.php'); 	
		 $update_product = new update_product();
	}
	
	public function delete_product()
	{
		require_once('models/product/delete_product.php'); 	
	}
  }
?>