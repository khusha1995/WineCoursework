<?php

require_once('../../connection.php');
require_once('../../config.php');
$item_per_page=5;
//sanitize post value
if(isset($_POST["page"])){
	$page_number = filter_var($_POST["page"], FILTER_SANITIZE_NUMBER_INT, FILTER_FLAG_STRIP_HIGH);	//remove any foreign letters/numbers etc.
	if(!is_numeric($page_number)){die('Invalid page number!');} //incase of invalid page number
}else{
	$page_number = 1;
}

//get current starting point of records
$position = (($page_number-1) * $item_per_page);


 $db = Db::getInstance();
//get uniq. wine code, name, indicator, image, quant., cost from Wines table join with available
//limit the results to 5 items per page.
$results = $db->prepare("SELECT unique_wine_code,wine_name, wine_indicator, wineimage, quantity_available, cost_of_wine FROM wines LEFT OUTER  JOIN quantity_available ON wines.quantity_available_id = quantity_available.quantity_available_id
LEFT OUTER  JOIN cost_of_wine ON wines.cost_of_wine_id = cost_of_wine.cost_of_wine_id LIMIT $position, $item_per_page");


$results->execute();
//getting results from database
?>

<table class="table table-striped table-advance table-hover">
	                  	  	  <h4><i class="fa fa-angle-right"></i> Wines List: </h4>
	                  	  	  <hr>
                              <thead>
                                  <tr>
                                      <th><i class=""></i> Images</th>  
                                      <th><i class=""></i> Product Name</th> 
                                      <th><i class=""></i>Wine Indicator</th>                                 
                                      <th><i class=""></i>Price (£)</th>
                                      <th><i class=""></i>Quantity Available</th>
                                      <th>Action</th>
                                  </tr>
                              </thead>
<?php
while($row = $results->fetch(PDO::FETCH_ASSOC))
{  ?>
						<tbody>	
                              <?php 
							   if(!empty($row)){ ?>
                              <tr>
                                  <td width="120px"><img src="<?php echo SITE_URL."views/product_images/".$row['wineimage']; ?>" width="120" height="120" /></td> 
                                  <td><?php echo $row['wine_name']; ?></td>
                                  <td><?php echo $row['wine_indicator']; ?></td>
                                  <td>£<?php echo $row['cost_of_wine']; ?></td>
                                  <td><?php echo $row['quantity_available']; ?></td>
                                  <td>
                                     <a href="<?php echo BASE_URL; ?>product/add_form/?<?php echo $row['unique_wine_code']; ?>" class="btn btn-primary btn-xs">Edit</a>
                                      <a href="<?php echo BASE_URL; ?>product/delete_product/?<?php echo $row['unique_wine_code']; ?>" class="btn btn-danger btn-xs">Delete</a>
                                  </td>
                              </tr>
                              <?php }else{ ?>
                              <tr>
                                  <td colspan="5">Product Not Found!</td> 
                              </tr>
                              <?php } ?>
                    </tbody>          
                              
                             
<?php }
?>
</table>