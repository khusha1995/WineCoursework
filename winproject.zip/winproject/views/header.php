<div class="header">
		<div class="headertop_desc">		<!-- line splitting Login from body -->
			<div class="account_desc">
				<ul>
                    <?php
                    if(isset($_SESSION['users'][0]['first_name'])){ ?>
                        <li><a href="javascirpt:void(0);"><?php echo $_SESSION['users'][0]['first_name']; ?></a></li>
                        <li><a href="<?php echo BASE_URL; ?>pages/account">Account</a></li>
                        <li><a href="<?php echo BASE_URL; ?>pages/logout">Logout</a></li>
                    <?php }else{ ?>
                        <li><a href="<?php echo BASE_URL; ?>pages/registor">Register</a></li>
                        <li><a href="<?php echo BASE_URL; ?>pages/login">Login</a></li>
                    <?php } ?>
				</ul>
			</div>
			<div class="clear"></div>
		</div>
		
		<div class="header_top">
			<div class="logo">
				<a href="<?php echo BASE_URL; ?>"><img src="<?php echo BASE_URL; ?>views/images/index_images/homeicon.png" alt ="10 green bottle icon"></a>
			</div>
			  <div class="cart">
			  	   <p><span>Cart:</span></p><div id="dd" class="wrapper-dropdown-2 ">
                      <?php
                      $total=0.00;
                      if(isset($_SESSION['users'])){
                          $cartDetail=GetCartDataWhenUserLogin();
                          
                          if($cartDetail){
                              $TotalItem = count($cartDetail);
                              foreach ($cartDetail as $cart){
                                  $total+=$cart['total'];
                              }
                      }}elseif(isset($_SESSION['cart'])){
                          $TotalItem = count($_SESSION['cart']);

                          foreach ($_SESSION['cart'] as $cart){
                              $total+=$cart['price'];
                          }
                      } ?>
                      <span class="cart-item-price"><?php echo isset($TotalItem) ? $TotalItem  : 0 ; ?> item(s) - £<?php echo $total;?></span>
			  	   	<ul class="dropdown cartTableData">
                        <?php
                        if(isset($_SESSION['users'])){
                            $cartDetail=GetCartDataWhenUserLogin();
                            if($cartDetail){
                                foreach ($cartDetail as $cart){ ?>
                                    <li>
                                        <div style="width:100%">
                                            <div style="width:50%;">
                                                <img src="<?php echo BASE_URL.'views/product_images/'.$cart['wineimage']; ?>" alt="">
                                            </div>
                                            <div style="width:50%;"></div>
                                            <p>Item  : <?php echo $cart['wine_name']; ?></p><br>
                                            <p>qty   : <?php echo $cart['quantity_available_id']; ?></p><br>
                                            <p>price :£<?php echo $cart['total']; ?></p>
                                            <br><hr>
                                        </div>
                                    </li>
                                <?php } ?>
                                <a href="<?php echo BASE_URL.'pages/view_cart'; ?>">View cart</a>
                            <?php }else{ ?>
                                <li>Nothing here ...yet :)</li>
                            <?php }}
                        elseif(isset($_SESSION['cart'])){
                            foreach ($_SESSION['cart'] as $cart){
                                ?>
                                <li>
                                    <div style="width:100%">
                                        <div style="width:50%;">
                                            <img src="<?php echo BASE_URL.'views/product_images/'.$cart['item_image']; ?>" alt="">
                                        </div>
                                        <div style="width:50%;"></div>
                                        <p>Item : <?php echo $cart['name']; ?></p><br>
                                        <p>qty  : <?php echo $cart['qty']; ?></p><br>
                                        <p>price :£<?php echo $cart['price']; ?></p>
                                        <br><hr>
                                    </div>
                                </li>
                            <?php } ?>
                            <!--<a href="<?php /*echo BASE_URL.'pages/view_cart'; */?>">View cart</a>-->
                        <?php } else{ ?>
                            <li>Nothing here ...yet :)</li>
                        <?php } ?>

                        <a href="<?php echo BASE_URL.'pages/view_cart'; ?>">View cart</a>

					</ul></div><p></p>
			  </div>
			  <script type="text/javascript">
			function DropDown(el) {
				this.dd = el;
				this.initEvents();
			}
			DropDown.prototype = {
				initEvents : function() {
					var obj = this;

					obj.dd.on('click', function(event){
						$(this).toggleClass('active');
						event.stopPropagation();
					});	
				}
			}

			$(function() {

				var dd = new DropDown( $('#dd') );

				$(document).click(function() {
					// all dropdowns
					$('.wrapper-dropdown-2').removeClass('active');
				});

			});

		</script>
	 <div class="clear"></div>
  </div>
	<div class="header_bottom">
	     	<div class="menu">
	     		<ul>
			    	<li><a href="<?php echo BASE_URL; ?>pages/home">Home</a></li>
			    	<li><a href="<?php echo BASE_URL; ?>pages/about">About</a></li>
			    	<li><a href="<?php echo BASE_URL; ?>pages/contact">Contact</a></li>
			    	<div class="clear"></div>
     			</ul>
	     	</div>
	     	<div class="search_box">
	     		<form action="<?php echo BASE_URL; ?>index.php" method="post">
                	<input type="hidden" name="action" value="search" />
                    <input type="hidden" name="controller" value="pages" />
	     			<input value="" placeholder="Search Product Name" name="product_name" type="text"><input name="search" value="" type="submit">
	     		</form>
	     	</div>
	     	<div class="clear"></div>
	     </div>	     
	
   </div>