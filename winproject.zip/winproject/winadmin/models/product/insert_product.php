<?php
class insert_product{
	public function __construct(){
		if(isset($_POST['submit']) && isset($_POST['wine_name']))
		{
			
			$db = Db::getInstance();
			$unique_wine_code=rand();
			$tmp_name = $_FILES["p_images"]["tmp_name"];
             $name = basename($_FILES["p_images"]["name"]);
			$uploads_dir="../views/product_images";
			$RandomAccountNumber = uniqid();
			$name=$RandomAccountNumber."_".$name;
            move_uploaded_file($tmp_name, "$uploads_dir/$name");			
			 $slug=create_product_slug($_POST['wine_name']);
			  
			 
			//insert the data into the quantity available table
			$quantity=uniqid();
			$qry1="INSERT INTO quantity_available (`quantity_available_id`,`quantity_available`)VALUES('".$quantity."','".$_POST['p_quantity']."')";
			$db->query($qry1);
			
			$cost_id=uniqid();
			$qry2="INSERT INTO cost_of_wine(`cost_of_wine_id`,`cost_of_wine`) VALUES ('".$cost_id."','".$_POST['cost_of_wine']."')";
			$db->query($qry2);
			$slug= $slug."_".$cost_id;
			
			$qry3="INSERT INTO wines (`unique_wine_code`,`wine_name`, `description`,`wine_indicator`,`quantity_available_id`,`cost_of_wine_id`,`wineimage`,`slug`)
		VALUES ('".$unique_wine_code."','".$_POST['wine_name']."','".$_POST['description']."','".$_POST['wine_indicator']."','".$quantity."','".$cost_id."','".$name."','".$slug."')";
		
			$db->query($qry3); 
			
			
			$cat_name=str_replace(" ","_",$_POST['category_name']);
			$wine_category_id=uniqid();
			$qry4="INSERT INTO wine_category(`wine_category_id`,`category_name`,`unique_wine_code`) VALUES ('".$wine_category_id."','".$cat_name."','".$unique_wine_code."')";
			$db->query($qry4);
			
			header("Location:".BASE_URL);
		}
	}
}
?>