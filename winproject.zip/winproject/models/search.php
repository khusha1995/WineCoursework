<?php
class Search
{
	//the result of the search
	public $resule_cat1;
	public function __construct()
	{
		//search from the wines and present the wine name, cost & id
		if(isset($_POST['search']))
		{	
			$db = Db::getInstance();
			$product_query = "select * from wines
			LEFT OUTER JOIN cost_of_wine
            on wines.cost_of_wine_id=cost_of_wine.cost_of_wine_id where wines.wine_name LIKE '".$_POST['product_name']."'"; 
			$this->resule_cat1=$db->prepare($product_query);
			 $this->resule_cat1->execute();
			 $this->resule_cat1=$this->resule_cat1->fetchAll();
			 return $this->resule_cat1;
		}
	}
}
?>