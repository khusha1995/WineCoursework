<?php
class Contact_detail
{
	public function __construct()
	{
		//Contact form that is created when user submits a form using the contact page, Win10-Email friendly... styling was created using trial-n'-error method of sending email and adjusting styling accordingly
		if(isset($_POST['contact']))
		{
			$to = "k1315975@kingston.ac.uk";        /*CHANGE TO THE PERSON WHO WILL BE MANAGING ALL EMAILS FOR THE WEBSITE*/
			$subject = "Contact Us!";
			$txt = '
				
    <table border="0" cellpadding="0" cellspacing="0" height="100%" width="100%">
        <tbody>
        <tr>
          <td align="center" valign="top"><div id="header_image"> </div>
            <table border="0" cellpadding="0" cellspacing="0" width="600" id="container" ">
              <tbody>
                <tr>
                  <td align="center" valign="top"><table border="0" cellpadding="0" cellspacing="0" width="600" id="header">
                      <tbody>
                        <tr>
                          <td id="header_wrap"><h1>The Message A User Has Sent:</h1></td>
                        </tr>
                      </tbody>
                    </table></td>
        </tr>
				
                <tr>
                  <td align="center" valign="top"><table border="0" cellpadding="0" cellspacing="0" width="600" id="body1">
                      <tbody>
                        <tr>
                          <td valign="top" id="body"><table border="0" cellpadding="20" cellspacing="0" width="100%">
                              <tbody>
                                <tr>
                                  <td valign="top" style="padding:48px"><div id="body_inner">
                                      <table class="table_inner_inner" cellspacing="0" cellpadding="6">
                                        <tbody>
                                         
                                        </tbody>
                                        <tfoot>
                                          <tr>
                                            <th class="username" scope="row" colspan="2">User Name:</th>
                                             <td class="username_post">'.$_POST['user'].'</td>
                                          </tr>
                                          <tr>
                                            <th class="emailaddress" scope="row" colspan="2">Email Address:</th>
                                            <td class="emailaddress_post">'.$_POST['email'].'</td>
                                          </tr>
                                          <tr>
                                            <th class="message" scope="row" colspan="2">User Message:</th>
                                            <td class="message_post">'.$_POST['usermessage'].'</td>
                                          </tr>
                                        </tfoot>
                                      </table>
                                    </div></td>
                                </tr>
                              </tbody>
                            </table></td>
                        </tr>
                      </tbody>
                    </table></td>
                </tr>
                
              </tbody>
            </table></td>
        </tr>
      </tbody>
    </table>
			';
			$headers = "From: masteradmin@gmail.com" . "\r\n" .
				"MIME-Version: 1.0" . "\r\n" . 
               "Content-type: text/html; charset=UTF-8" . "\r\n";

			mail($to,$subject,$txt,$headers);                   /*MAIL EVERYTHING THAT WAS CREATED ABOVE USING VARIABLES*/
			$_SESSION["contact_mail"] = "true";
			header('Location: '.BASE_URL.'pages/contact');	
		}
	}
}
?>