<?php
define('ENVIRONMENT', 'development');
switch (ENVIRONMENT) {
    case 'development':
        error_reporting(E_ALL);
        if ( ! ini_get('display_errors')) {
        ini_set('display_errors', 1);
    }
        break;

    case 'testing':
        // no break;
    case 'production':
        error_reporting(0);
        break;

    default:
        exit('The application environment is not set correctly.');
}


ini_set('session.gc_maxlifetime', 60000000);
// server should keep session data for AT LEAST 1 hour
ini_set('session.gc_maxlifetime', 60000000);

// each client should remember their session id for EXACTLY 1 hour
session_set_cookie_params(60000000);

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}



 global $action,$controller;
 require_once('connection.php');
 require_once('config.php');
 $REQUEST_URI=$_SERVER['REQUEST_URI'];
 $REQUEST_URI_ARRAY=explode('/',$REQUEST_URI);
 $REQUEST_URI_ARRAY = array_filter($REQUEST_URI_ARRAY, 'strlen');
if(sizeof($REQUEST_URI_ARRAY)>CONTROLLER_POSTION){

 $controller = $REQUEST_URI_ARRAY[CONTROLLER_POSTION];
 	if($controller=="product" || $controller=="category"){	$action="view"; }
} 
if (isset($_POST['controller']) && isset($_POST['action'])) {
   $controller = $_POST['controller'];
   $action     = $_POST['action'];
}

if($action == NULL){ $action='home'; }
if($controller == NULL){ $controller='pages';}


 require_once('views/layout.php');
?>