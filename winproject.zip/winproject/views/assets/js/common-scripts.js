  jQuery('#sidebar .sub-menu > a').click(function () {
       $(".sub-menu > a").removeClass("active");
          if ( $(this).next().is( ":hidden" ) ) {
			  $(".sub-menu > a").next().slideUp( "slow" );
				$(this).next().slideDown( "slow" );
			  } else {
				$(this).next().slideUp("slow");
			  }
			   $(this).addClass("active");
    });
	
	$('#sidebar .sub-menu > .active').next().slideDown( "slow" );