<?php 
class Acoount_dtl           /*UPDATE USER DETAILS IF THEY CHOSE TOO. */
{                           /*UPDATE: EMAILADDRESS, DOB, TITLE, FNAME, LNAME. NOT USERNAME!*/
	public function __construct()
	{
		if(isset($_POST['update']))	
		{
			//update user account details
			$db = Db::getInstance();
			$qry = "UPDATE customer SET email_address='".$_POST['email']."', 
			date_of_birth='".$_POST['dob']."',title='".$_POST['title']."',first_name='".$_POST['fname']."',
			last_name='".$_POST['lname']."' WHERE username='".$_SESSION['users'][0]['username']."'";
			$db->query($qry); 
			
			
			session_start();
			$_SESSION["reg_dtl_upd_success"] = "true";          /*if success take back to account page.*/
			header("Location:".BASE_URL."pages/account");	
		}
	}
}
?>