<?php
class update_product{
	public function __construct()
	{
		if(isset($_POST['product_id']))
		{ 
		    $product_id=$_POST['product_id'];
			$db = Db::getInstance();
			//update the wine image
			$tmp_name = $_FILES["p_images"]["tmp_name"];
			if($tmp_name != NULL){
			$name = basename($_FILES["p_images"]["name"]);
				$uploads_dir="../views/product_images";
				$RandomAccountNumber = uniqid();
				$name=$RandomAccountNumber."_".$name;
				move_uploaded_file($tmp_name, "$uploads_dir/$name");
			}
			//show all the wines
			$qry1="select * from wines where unique_wine_code=".$product_id;
			$select_product_data=$db->prepare($qry1);
	 	 	$select_product_data->execute();
	     	$select_product_data = $select_product_data->fetchAll();
			 $slug=create_product_slug($_POST['wine_name']);
			
			//update the quantity
			$qry2="UPDATE quantity_available SET `quantity_available`='".$_POST['p_quantity']."' WHERE `quantity_available_id` ='".$select_product_data[0]['quantity_available_id']."'";
			$db->query($qry2);
			
			//update the cost
			$cost_id=uniqid();
			$slug= $slug."_".$cost_id;
			$qry3="UPDATE cost_of_wine SET `cost_of_wine`='".$_POST['cost_of_wine']."' WHERE `cost_of_wine_id` ='".$select_product_data[0]['cost_of_wine_id']."'";
			$db->query($qry3);
			
			//if the wine image isn't empty then update wine name, description, wine indicator, quantity, cost, 
			 if($name != NULL)
			 {
				$qry4="UPDATE  wines SET `wine_name`='".$_POST['wine_name']."',`slug`='".$slug."',`description`='".$_POST['description']."',`wineimage`='".$name."',`wine_indicator`='".$_POST['wine_indicator']."',`quantity_available_id`='".$select_product_data[0]['quantity_available_id']."',`cost_of_wine_id`='".$select_product_data[0]['cost_of_wine_id']."' where unique_wine_code='".$product_id."'";
			 }else
			 {
				 //else update wine name, description, wine indicator, quantity, cost, uniqu. wine code. BUT leave out wine image as none given
				$qry4="UPDATE  wines SET `wine_name`='".$_POST['wine_name']."',`slug`='".$slug."',`description`='".$_POST['description']."',`wine_indicator`='".$_POST['wine_indicator']."',`quantity_available_id`='".$select_product_data[0]['quantity_available_id']."',`cost_of_wine_id`='".$select_product_data[0]['cost_of_wine_id']."' where unique_wine_code='".$product_id."'";
			 }
			$db->query($qry4);
			
			$qry5="UPDATE wine_category SET `category_name`='".$_POST['category_name']."' where unique_wine_code='".$product_id."'";
			$db->query($qry5);
		}
		header("Location:".BASE_URL);
	}
}
?>