<div class="main">
    <div class="content">
    	<div class="section group">
				<div class="cont-desc span_1_of_2">
                <?php foreach($slug->slug as $slug_data){ ?>
				  <div class="product-details">				
					<div class="grid images_3_of_2">
						<div id="container">
							<div id="alcoholimage">
								<a href="#"><img src="<?php echo BASE_URL; ?>views/product_images/<?php echo $slug_data['wineimage']; ?>" alt="wine images of different wine types" /></a> <!--get wines image-->
							</div>
						</div>
					</div>
				<div class="desc span_3_of_2">
					<h2><?php $slug=str_replace("_"," ",$slug_data['wine_name']); echo $slug; ?></h2>           <!--get chosen wines name -->
									
					<div class="price">
						<p>Price: <span>£<?php echo $slug_data['cost_of_wine']; ?></span></p>                   <!--get chosen wines £-->
					</div>
				<div class="share-desc">
					<div class="button"><span><a href="javascript:void(0)" data-unique_wine_code="<?php echo $slug_data['unique_wine_code']; ?>" class="add-product">Add</a></span></div>					
					<div class="clear"></div>
				</div>
				</div>
			<div class="clear"></div>
				   </div>
          
          <?php if($View_review->product_review[0]['product_id'] == $slug_data['unique_wine_code']){ ?>
 <!--REVIEWS--><p>Other Reviews: </p>
          <?php foreach($View_review->product_review as $product_review){ ?>
         <div class="resp-tabs-container">
         		<p style="font-weight: bold;"><?php echo $product_review['username']; ?></p>																							
                <p><?php echo $product_review['review']; ?></p>
         </div>
         <?php } } ?>
          <br><br><br>
		<div class="product_desc">	
				<ul class="resp-tabs-list">
					<li>Product Details:</li>
					<div class="product-desc">
						<p><?php echo $slug_data['description']; ?></p>
    				</div>
					<br><br><br><br><br>
					<li>Why don't you add a review?</li>
					<div class="clear"></div>
				
				<div class="resp-tabs-container">
				<div class="review">
				  <div class="your-review">
				  	  <p>Remember: * = Mandatory</p>
				  	  <form action="<?php echo BASE_URL; ?>index.php" method="post">
                      		<input type="hidden" name="action" value="review" />
                			<input type="hidden" name="controller" value="pages" />
                            <input type="hidden" name="product_id" value="<?php echo $slug_data['unique_wine_code'];?>" />
                            <input type="hidden" name="slug" value="<?php echo $slug_data['slug'];?>" />
					    	<div>
						    	<span><label><i>Name: </i><span class="red">*</span></label></span>
						    	<span><input type="text" name="username" value="<?php if(isset($_SESSION['users'])){ echo $_SESSION['users'][0]['username']; } ?>"></span>
						    </div>					
						    <div>
						    	<span><label>Review: <span class="red">*</span></label></span>
						    	<span><textarea name="userreview"> </textarea></span>
						    </div>
						   <div>
						   		<span><input type="submit" name="review" value="Send"></span>
						  </div>
					   </form>
				  </div>				
				</div>
			    </div>
			    </ul>
		    
	    </div>
   <?php } ?>		
        </div>
 		</div>
 	</div>
    </div>