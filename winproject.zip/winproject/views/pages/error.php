<p>Ah' something has gone wrong, please use the back button or just press the home button and start over</p>
<p>That should hopefully fix it U+1F609</p>