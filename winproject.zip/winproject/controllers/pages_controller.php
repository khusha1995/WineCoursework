<?php
  class PagesController 
  {
    public function home() 
	{
		//load model page
	  require_once('models/view_category.php');	
      //view_category= new View_category();
	  //get data, display category in homepage 
	  $view_category_dsp_home= new View_category_dsp_home();
	  //user view home page
	  //$display_product= display_product();
      require_once('views/pages/home.php');
    }


    public function view_cart()
	{
		//load model page
        require_once('models/wineusers.php');

        if(isset($_POST['process_to_checkout']))
		{
			//get cart data
            $wineUsers= new Wineusers();
            if($wineUsers->UpdateCartData())
            {
				//user view checkout page
                header('Location: '.BASE_URL.'pages/checkout');
            }

        }
		//user view cart page
        require_once('views/pages/view_cart.php');
    }


    public function checkout()
	{	
		//load model page
		require_once('models/checkout.php');
		//get checkout product display detail
		$Checkout_product_details=new Checkout_product_details();
		//insert order 
		$Checkout= new Checkout();
		//user view checkout page
        require_once('views/pages/checkout.php');
    }
	
	
	public function about() 
	{
		//user view about page
      require_once('views/pages/about.php');
    }
	
	
	public function contact() 
	{
		//user view contact page
      require_once('views/pages/contact.php');
    }


	public function login()
	{
        $flg=0;
		//load model
        require_once('models/wineusers.php');
		//user check to ensure user has typed into the field, otherwise go and give a error
        if(isset($_POST['login-btn']))
		{
            if(empty($_POST['user_id']))
			{
                $user_id = "Please type your User ID first";
                $flg=1;
            }

            if(empty($_POST['password']))
			{
                $password = "Please type the associated password too";
                $flg=1;
            }

            if($flg != 1)
			{
                $wineUsers= new Wineusers();

                if($wineUsers->insert()==false){
                    $error = "Please re-check the User ID and Password, they don't seem to match any credentials we have";
                    $flg=1;
                }else{
                    $wineUsers->StoreDataToCart();
                    header('Location: '.BASE_URL);
                }
            }else
			{
                $error = "The '*' means mandatory - Please check the fields";
            }
		}
	//user view > login page
     require_once('views/pages/login.php');
    }
	
	
    public function review() 
	{
		  //load model page
          require_once('models/review.php');
		  //get review
          $review = new Review();
    }


    public function logout()
	{
          //unset the user
		  //user is logged out, the session is unset
          session_start();
          session_destroy();
          header('Location: '.BASE_URL);
    }
	
    public function registor() 
	{
		  //user view registor page
          require_once('views/pages/registor.php');
    }
	
	
    public function insert_registor() 
	{
		  //load model page
          require_once('models/registor.php');
		  //insert registor details
          $Insert_registor = new Insert_registor();
    }
	
	
	public function thankyou() 
	{
		  //user view -> thankyou page
          require_once('views/pages/thankyou_page.php');
    }
	
	
	public function account() 
	{
	  //load model page
	  require_once('models/account.php');
	  //get order details	
	  $Order_details=new Order_details();
	  //get account details
	  $acoount_details=new Acoount_details();
	  //user view account page
      require_once('views/pages/account.php');
    }
	
	
	public function account_detail()
	{
	  //load model page
	  require_once('models/account_detail.php');
	  //update account details
	  $Acoount_dtl=new Acoount_dtl();	
	}
	
	
	public function change_pwd() 
	{
	  //load model page
      require_once('models/change_pwd.php');
	  //set changed user password
	  $Changepwd=new Changepwd();
    }
    
    
	public function contact_detail()
	{
	  //load model page
	  require_once('models/contact_detail.php');
	  //mail a contact detaol
	  $contact_detail=new Contact_detail();	
	}
	
	
	public function search()
	{
	  //load model page
	  require_once('models/search.php');
	  //get search details
	  $search=new Search();
	  //user view > search result in the homepage
	  require_once('views/pages/home.php');			
	}
	
	
    public function error() {
		//user view > error page
      require_once('views/pages/error.php');
    }

  }
?>