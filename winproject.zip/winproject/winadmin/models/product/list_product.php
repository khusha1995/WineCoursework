<?php
class List_product{
	public $resule_product;
	public $results;
 
    public function __construct(){
		global $id;
       $db = Db::getInstance();
	   $item_per_page=6;
	   $results = "SELECT COUNT(*) FROM wines LEFT OUTER  JOIN quantity_available ON wines.quantity_available_id = quantity_available.quantity_available_id
					LEFT OUTER  JOIN cost_of_wine ON wines.cost_of_wine_id = cost_of_wine.cost_of_wine_id";
					
		$this->results=$db->prepare($results);
		$this->results->execute();
		$this->results = $this->results->fetchAll();
   }
}
  
?>