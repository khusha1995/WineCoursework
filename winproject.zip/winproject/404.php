<?php
global $action,$controller,$slug;

 require_once('connection.php');
 require_once('config.php');
 $REQUEST_URI=$_SERVER['REQUEST_URI'];
 $REQUEST_URI_ARRAY=explode('/',$REQUEST_URI); 


$REQUEST_URI_ARRAY = array_filter($REQUEST_URI_ARRAY, 'strlen');



if(sizeof($REQUEST_URI_ARRAY)>CONTROLLER_POSTION){
	
 $controller = $REQUEST_URI_ARRAY[CONTROLLER_POSTION];
  $controller = $controller;
   $action     = $REQUEST_URI_ARRAY[CONTROLLER_POSTION+1];
  if($controller=="product" || $controller=="category"){
	 $slug= $REQUEST_URI_ARRAY[CONTROLLER_POSTION+1];
	 $action="view"; 
  }

}

if (isset($_POST['controller']) && isset($_POST['action'])) {
   $controller = $_POST['controller'];
   $action     = $_POST['action'];
}

if($action == NULL){ $action='home'; }
if($controller == NULL){ $controller='pages'; }

 

 require_once('views/layout.php');
?>