<?php
class ProductController 
{
    public function view() 
	{
      // we store all the posts in a variable
	  $slug= new Product();
      $View_review= new View_review();
		
      require_once('views/product/product_details.php');
    }
}
?>