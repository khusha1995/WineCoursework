<?php 
$db = Db::getInstance();
global $id;
//select all wines using the unique wine code for each
$qry1="select * from wines where unique_wine_code=".$id[1];
			$select_product_data=$db->prepare($qry1);
	 	 	$select_product_data->execute();
	     	$select_product_data = $select_product_data->fetchAll();
//delete the wine from the wine category
$qry5="delete from `wine_category` where `unique_wine_code`='".$id[1]."'";
$db->query($qry5);
//delete the wine from the wine table
$qry4="delete from `wines` where `unique_wine_code`='".$id[1]."'";
$db->query($qry4);			
//delete the wine quantity
$qry2="delete from `quantity_available` where `quantity_available_id`='".$select_product_data[0]['quantity_available_id']."'";
$db->query($qry2);
//delete the wine cost
$qry3="delete from `cost_of_wine` where `cost_of_wine_id`='".$select_product_data[0]['cost_of_wine_id']."'";
$db->query($qry3);
			
//take user back to admin page
header("Location:".BASE_URL);
?>