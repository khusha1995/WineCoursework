<?php
global $action,$controller;

 require_once('connection.php');
 require_once('config.php');
 $REQUEST_URI=$_SERVER['REQUEST_URI'];
 $REQUEST_URI_ARRAY=explode('/',$REQUEST_URI); 


$REQUEST_URI_ARRAY = array_filter($REQUEST_URI_ARRAY, 'strlen');


if(sizeof($REQUEST_URI_ARRAY)>CONTROLLER_POSTION)
{
 $controller = $REQUEST_URI_ARRAY[CONTROLLER_POSTION];
 
 $action_postion=CONTROLLER_POSTION+1;
 $action    = $REQUEST_URI_ARRAY[$action_postion];
}

if (isset($_POST['controller']) && isset($_POST['action'])) 
{
  $controller = $_POST['controller'];
   $action     = $_POST['action'];
} 

 if($action == NULL)
 { 
	$action='home'; 
 }
 
 if($controller == NULL)
 { 
	$controller='pages'; 
 }
 userlogin_checking();		//check user is still logged in.
							//created in lib > function
 

 require_once('views/layout.php');		//require page properties such as webpage title, css,js etc.
?>