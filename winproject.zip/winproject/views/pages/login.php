<div class="main">
    <div class="content">
        <div class="section group">
            <div class="col_1_of_3 span_1_of_3">
                <div id="login-page">
                    <?php if($flg==1){ ?>
                    <div class="required-field">
                        <?php echo $error;?>.
                    </div>
                    <?php } ?>
                    <div class="container">
                        <form class="form-login" action="<?php echo BASE_URL; ?>index.php"
                              enctype="multipart/form-data" method="post">
                            <input type="hidden" name="action" value="login"/>
                            <input type="hidden" name="controller" value="pages"/>
							<?php 
								//session_start();
								if(isset($_SESSION["registor_success"]) == "true"){
							?>
                            	<p>You've successfully registered! Login Now.</p>
                            <?php session_unset($_SESSION["registor_success"]); 
							}elseif(isset($_SESSION["changepwd_success"]) == "true"){ ?>
                            	<p>You successfully Change Your Password.</p>
                            <?php session_unset($_SESSION["changepwd_success"]);} ?>
							
                            <h2 class="form-login-heading">sign in!</h2>
                            <div class="login-wrap">
                                <input type="text" class="form-control" name="user_id" placeholder="User ID" autofocus><span class="required-field">*</span>
                                <br>
                                <span class="help-block required-field"><?php  echo isset($user_id) ? $user_id : ''; ?></span>
                                <br>
                                <input type="password" class="form-control" name="password" placeholder="Password"><span class="required-field">*</span>
                                <br>
                                <span class="help-block required-field"><?php echo  isset($password) ? $password : ''; ?></span>
                                <label class="checkbox">
									<span class="pull-right">
									<a data-toggle="modal" href="login.html#myModal"> &nbsp;</a>
									</span>
                                </label>
								<br/>
                                <p><input type="submit" class="btn btn-theme btn-block" name="login-btn" value="Submit"></p>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
