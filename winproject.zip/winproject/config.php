<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
define("BASE_URL",'');
define("CONTROLLER_POSTION",2);
//split the base url into segments, each segment is split using the "/", so right now in
//the BASE_URL there is 2 segments, with the Controller_position, we will put all links AFTER the 2nd segment "/winproject/"

$actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
$expload_url=explode('/',$actual_link);
?>