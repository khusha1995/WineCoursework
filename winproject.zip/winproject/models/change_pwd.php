<?php
class Changepwd
{
	//change user password
	//used md5 for pass encryption
	public function __construct()
	{
		$db = Db::getInstance();
		$user = $_SESSION['users'];
		if ($_POST['chngpwd'])
		{ 
			$oldpassword = md5($_POST['oldpwd']);
			$query = "SELECT password FROM customer WHERE username='".$_SESSION['users'][0]['username']."'";	
			$changepwd=$db->prepare($query);
	 		$changepwd->execute();
	 		$changepwd = $changepwd->fetchAll();
			$oldpassworddb = $changepwd[0]['password'];
			
			if ($oldpassword==$oldpassworddb)
			{
				$querychange = "UPDATE customer SET password='".md5($_POST['newpwd'])."' WHERE username='".$_SESSION['users'][0]['username']."'";
				$db->query($querychange);
				//remove user from session and take back to the login page
				if(isset($_SESSION["users"])) { unset($_SESSION["users"]); } 
				$_SESSION["changepwd_success"] = "true";
				header("Location:".BASE_URL."pages/login");
			}
			//if any form of error occurs, take the user back to the account page.
			else
			{ 
            	$_SESSION["changepwd_error"] = "error";	
				header("Location:".BASE_URL."pages/account");
			 }
		}
	}	
}
?>