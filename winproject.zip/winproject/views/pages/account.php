<div class="account">
<nav class="account-MyAccount-navigation">
	<ul>
			<li class="account-MyAccount-navigation-link account-MyAccount-navigation-link--dashboard is-active" id="dashboard">
				<a href="#">Home</a>
			</li>
            <li class="account-MyAccount-navigation-link account-MyAccount-navigation-link--dashboard is-active" id="change_pwd">
				<a href="#">Change Password</a>
			</li>
			<li class="account-MyAccount-navigation-link account-MyAccount-navigation-link--orders" id="order_details">
				<a href="#">Orders Details</a> 
			</li>
			<li class="account-MyAccount-navigation-link account-MyAccount-navigation-link--edit-account" id="account_details">
				<a href="#">Account Details</a>
			</li>
			<li class="account-MyAccount-navigation-link account-MyAccount-navigation-link--customer-logout">
				<a href="<?php echo BASE_URL; ?>pages/logout">Logout</a>
			</li>
					
	</ul>
</nav>
<?php  
	/*session_start();*/ 
	if(isset($_SESSION["changepwd_error"]) == "error"){ ?>
    	<p>Old Password Does Not Match</p> 
	<?php unset($_SESSION["changepwd_error"]); }
	elseif(isset($_SESSION["reg_dtl_upd_success"]) == "true"){ ?>
		<p>Your Account Details Have Successfully Been Updated!</p> 
	<?php unset($_SESSION["reg_dtl_upd_success"]); } ?>
	
<div class="account-MyAccount-content">	                       
	<div class="dashboard">
        <p>Hello, <strong><?php if(isset($_SESSION['users'])){ echo $_SESSION['users'][0]['username']; } ?></strong></p>
        <p>From your account dashboard you can view your orders Details, Account Details & Change Password</p>
	</div>
    <div class="change_pwd">
    	<form action="<?php echo BASE_URL; ?>index.php" id="chngpwd" method="post">
        	<input type="hidden" name="action" value="change_pwd" />
            <input type="hidden" name="controller" value="pages" />
        	 <p><label>Old Password</label></p>
		            <p><input type="password" class="form-control" id="oldpwd" name="oldpwd" placeholder=""> <br></p>
             <p><label>New Password</label></p>
		            <p><input type="password" class="form-control" id="newpwd" name="newpwd" placeholder=""> <br></p> 
             <p><input type="submit" class="btn btn-theme btn-block" id="chngpwd" name="chngpwd" value="Change Password"></p>             
        </form>
    </div>
	
     <div class="order_details">
     <table>
     	<tbody>
            <tr>
                <th>Product Name</th>
                <th>Quantity</th>
                <th>Price</th>
                <th>Total Price</th>
                <th>Order Date</th>
            </tr>
            <?php foreach($Order_details->order_product_details as $order_data_display){  ?>
            <tr>
            	<td><?php echo $order_data_display['wine_name']; ?></td>
                <td><?php echo $order_data_display['quantity_available_id']; ?></td>
                <td>£<?php echo $order_data_display['cost_of_wine']; ?></td>
                <td>£<?php echo $order_data_display['total']; ?></td>
                <td><?php echo $order_data_display['order_date']; ?></td>
            </tr>
			<?php } ?>
        </tbody>    
     </table>
    </div>
	
    <div class="account_details">
        <?php foreach($acoount_details->account_details as $account_details){  ?>
    	<form action="<?php echo BASE_URL; ?>index.php" method="post">
        <input type="hidden" name="action" value="account_detail" />
        <input type="hidden" name="controller" value="pages" />
        <p><label>UserName </label></p>
        <p>	
        	<input type="text" class="form-control" name="user_name" value="<?php echo $account_details['username']; ?>" placeholder="" disabled="disabled">
        </p>
        <p><label>Email Address</label></p>
        <p>
        	<input type="text" class="form-control" name="email" placeholder="" value="<?php echo $account_details['email_address']; ?>">
        </p>
        <p><label>Date Of Birth</label></p>
        <p>
        	<input type="text" class="form-control" name="dob" placeholder="" value="<?php echo $account_details['date_of_birth']; ?>">
        </p>
        <p><label>Title</label></p>
        <p>
        	<input type="text" class="form-control" name="title" placeholder="" value="<?php echo $account_details['title']; ?>">
        </p>
        <p><label>First Name</label></p>
        <p>
        	<input type="text" class="form-control" name="fname" placeholder="" value="<?php echo $account_details['first_name']; ?>">
        </p>
        <p><label>Last Name</label></p>
        <p>
        	<input type="text" class="form-control" name="lname" placeholder="" value="<?php echo $account_details['last_name']; ?>">
        </p>  
        <p>
        <input type="submit" class="btn btn-theme btn-block" name="update" value="Update">
        </p>
       </form> 
       <?php } ?>
    </div>		
</div>
</div>

<script type="text/javascript">
$(document).ready(function() {			
	$("#dashboard").click(function(e) {
		$('.change_pwd').css('display','none');
		$('.order_details').css('display','none');
		$('.account_details').css('display','none');
		$('.dashboard').css('display','block');
	});
	$("#change_pwd").click(function(e) {
		$('.dashboard').css('display','none');
		$('.change_pwd').css('display','block');
		$('.order_details').css('display','none');
		$('.account_details').css('display','none');
	});
	$("#order_details").click(function(e) {
		$('.dashboard').css('display','none');
		$('.change_pwd').css('display','none');
		$('.account_details').css('display','none');
		$('.order_details').css('display','block');
	});
	$("#account_details").click(function(e){
		$('.dashboard').css('display','none');
		$('.change_pwd').css('display','none');
		$('.account_details').css('display','block');
		$('.order_details').css('display','none');
	});
});
</script>