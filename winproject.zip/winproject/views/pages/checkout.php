<link rel="stylesheet" type="text/css" href="<?php echo BASE_URL; ?>views/css/main-styles.css">

<link rel="dns-prefetch" href="http://fonts.googleapis.com/">

<link rel="stylesheet" id="contact-form-7-css" href="<?php echo BASE_URL; ?>views/css/styles.css" type="text/css" media="all">

<div id="primary" class="container">
    <main id="main" class="site-main" role="main">
        <div class="checkout">
			<?php
			//session_start();
			if(!isset($_SESSION['users'])){
			?>
            <div class="checkout-info">Returning customer? <a

                    href="<?php echo BASE_URL; ?>pages/login" class="showlogin">Login</a></div>
             <?php } ?>       

            <form class="checkout checkout-checkout" action="<?php echo BASE_URL; ?>index.php"

                enctype="multipart/form-data" method="post">

                <input type="hidden" name="action" value="checkout"/>
                <input type="hidden" name="controller" value="pages"/>
                <input type="hidden" name="page_name" value="thankyou"/>
                
                <div class="col2-set" id="customer_details">
                    <div class="col-1">
                        <div class="checkout-billing-fields">
                            <h3>--Billing Details--</h3>
                            <p class="form-row form-row form-row-first validate-required" id="billing_first_name_field"><label for="billing_first_name" class="">First Name
							<abbr class="required" title="required">*</abbr></label><input type="text" class="input-text" name="billing_first_name" id="billing_first_name"
							placeholder="" autocomplete="given-name" value=""></p>

                            <p class="form-row form-row form-row-last validate-required" id="billing_last_name_field"><label for="billing_last_name" class="">Last Name <abbr
							class="required" title="required">*</abbr></label><input type="text" class="input-text" name="billing_last_name" id="billing_last_name"
							placeholder="" autocomplete="family-name" value=""></p>

                            <div class="clear"></div>

                            <p class="form-row form-row form-row-wide" id="billing_company_field"><label for="billing_company" class="">Company Name</label><input type="text"
							class="input-text " name="billing_company" id="billing_company" placeholder="" autocomplete="organization" value=""></p>

                            <p class="form-row form-row form-row-first validate-required validate-email" id="billing_email_field"><label for="billing_email" class="">Email Address <abbr
							class="required" title="required">*</abbr></label><input type="email" class="input-text " name="billing_email" id="billing_email" placeholder="" autocomplete="email"
							value="" ></p>

							<p class="form-row form-row form-row-last validate-required validate-phone" id="billing_phone_field"><label for="billing_phone" class="">Phone <abbr
							class="required" title="required">*</abbr></label><input type="tel" class="input-text" name="billing_phone" id="billing_phone" placeholder="" autocomplete="tel"
							value=""></p>

                            <div class="clear"></div>

                            <p class="form-row form-row form-row-wide address-field update_totals_on_change validate-required checkout-validated" id="billing_country_field"><label for="billing_country" class="">Country </label>
							<select name="billing_country" id="billing_country" autocomplete="country" class="country_to_state" tabindex="-1" title="Country *" >
                                <option value="">Select a country </option>
                                <option value="GB">United Kingdom</option>
                            </select>
                            </p>

                            <p class="form-row form-row form-row-wide address-field validate-required" id="billing_address_1_field"><label for="billing_address_1" class="">Address <abbr
							class="required" title="required">*</abbr></label><input type="text" class="input-text" name="billing_address_1" id="billing_address_1" placeholder="Street address" autocomplete="address-line1"
							value="" ></p>

                            <p class="form-row form-row form-row-wide address-field" id="billing_address_2_field"> <input type="text" class="input-text " name="billing_address_2" id="billing_address_2" placeholder="Building Number"
							autocomplete="address-line2" value=""></p>

                            <p><label for="billing_city" class="">Town/City <abbr class="required" title="required">*</abbr></label></p>

                            <p style="margin-bottom:5px;"><input type="text" class="input-text " name="billing_city" id="billing_city" placeholder="" autocomplete="address-level2" value=""></p>

                            <p class="form-row form-row form-row-first address-field validate-state checkout-invalid checkout-invalid-required-field validate-required" id="billing_state_field"
							data-o_class="form-row form-row form-row-first address-field validate-required validate-state checkout-invalid checkout-invalid-required-field">

                            <label for="billing_state" class="">County <abbr class="required" title="required">*</abbr></label>

                            <select name="billing_state" id="billing_state" class="state_select " data-placeholder="" autocomplete="address-level1" tabindex="-1" title="County *">
                                <option value="">Select an option</option>
                                <option value="BA">Banffshire</option>
                                <option value="BD">Bedfordshire</option>
                                <option value="LN">London</option>
                                <option value="MD">Middlesex</option>
                                <option value="OX">Oxfordshire</option>
                            </select></p>
							
							<p class="form-row form-row form-row-last address-field validate-postcode validate-required" id="billing_postcode_field" data-o_class="form-row form-row form-row-last address-field validate-required validate-postcode">

                            <label for="billing_postcode" class="">Postcode <abbr class="required" title="required">*</abbr></label><input type="text" class="input-text " name="billing_postcode" id="billing_postcode"
							placeholder="" autocomplete="postal-code" value=""></p>

                            <div class="clear"></div>

							<?php
							//session_start();
							if(!isset($_SESSION['users'])){
							?>
							
                            <p class="form-row form-row-wide create-account checkout-validated"> <input class="input-checkbox" id="createaccount" type="checkbox" name="createaccount" value="1" checked="checked"> <label for="createaccount" class="checkbox">Need to create a account?</label>  
                            <input type="password"  class="input-text "  name="billing_pwd" />  
                            </p>
                            <?php } ?>
<br><br><br><br>

                            <div class="create-account">
                                <p>Enter ALL information to create a account. ...*IF YOU'RE A RETURNING CUSTOMER, PLEASE LOGIN*</p>

                                <p class="form-row form-row validate-required" id="account_username_field"><label for="account_username" class="">Account username <abbr class="required" title="required">*</abbr></label><input type="text" class="input-text " name="account_username"
								id="account_username" placeholder="Username" value=""></p>

                                <p class="form-row form-row validate-required" id="account_password_field"><label for="account_password" class="">Account password <abbr class="required" title="required">*</abbr></label><input
								type="password" class="input-text " name="account_password" id="account_password" placeholder="Password" value=""></p>

                                <div class="clear"></div>
                            </div>
                        </div>
                    </div>
                </div>
<br><br><br><br>
                <h3 id="order_review_heading">Your order:</h3>

                <div id="order_review" class="checkout-checkout-review-order">
                
				<?php if(isset($_SESSION['users'])){ foreach($Checkout_product_details->get_query as $cart_details){ 
					$basketid[]=$cart_details['shopping_basket_id'];
				?>
                
                    <table class="shop_table checkout-checkout-review-order-table">
                        <thead>
                        <tr>
                            <th class="product-name">Product</th>
                            <th class="product-total">Total</th>
                        </tr>
                        </thead>

                        <tbody>
                        <tr class="cart_item">
                            <td class="product-name">
                               <?php echo $cart_details['name']; ?>&nbsp; <strong class="product-quantity">× <?php echo $cart_details['quantity_available_id']; ?></strong>
								<input type="hidden" name="product_name[]" value="<?php echo $cart_details['name']; ?>" />
                                <input type="hidden" name="product_qty[]" value="<?php echo $cart_details['quantity_available_id']; ?>" />
                            </td>

                            <td class="product-total">
                                    <span class="checkout-Price-amount amount"><span class="checkout-Price-currencySymbol">£</span><?php echo $cart_details['cost_of_wine']; ?></span></td>
									<input type="hidden" name="product_cost_of_woine[]" value="<?php echo $cart_details['cost_of_wine']; ?>" />
                        </tr>
                        </tbody>

                        <tfoot>
                        <tr class="cart-subtotal">
                            <th>Subtotal:</th>
                            <td><span class="checkout-Price-amount amount"><span class="checkout-Price-currencySymbol">£</span><?php echo $cart_details['price']; ?></span></td>
							<input type="hidden" name="product_subtotal[]" value="<?php echo $cart_details['price']; ?>" />
                        </tr>

                        <tr class="order-total">
                            <th>Total:</th>
                            <td><strong><span class="checkout-Price-amount amount"><span class="checkout-Price-currencySymbol">£</span><?php echo $cart_details['price']; ?></span></strong></td>
							<input type="hidden" name="product_total[]" value="<?php echo $cart_details['price']; ?>" />
                        </tr>
                        </tfoot>
                    </table>
                    <br><br><br><br>
					
				<?php }
				if(!empty($basketid)){ 
				$implode_basket_id=implode(',',$basketid);
				?>
                <input type="hidden" name="basket_id" value="<?php echo $implode_basket_id; ?>" />
				<?php } }else{ foreach($Checkout_product_details->get_query as $cart_details){ ?>
				<?php $basketid[]=$cart_details['shopping_basket_id']; ?>
				
				<table class="shop_table checkout-checkout-review-order-table">
                        <thead>
                        <tr>
                            <th class="product-name">Product</th>
                            <th class="product-total">Total</th>
                        </tr>
                        </thead>

                        <tbody>
                        <tr class="cart_item">
                            <td class="product-name">
							    <?php echo $cart_details['name']; ?>&nbsp; <strong class="product-quantity">× <?php echo $cart_details['qty']; ?></strong>
								<input type="hidden" name="product_name[]" value="<?php echo $cart_details['name']; ?>" />
                                <input type="hidden" name="product_qty[]" value="<?php echo $cart_details['qty']; ?>" />
                            </td>

                            <td class="product-total"> <span class="checkout-Price-amount amount"><span class="checkout-Price-currencySymbol">£</span><?php echo $cart_details['orginal_price']; ?></span></td>
							<input type="hidden" name="product_cost_of_woine[]" value="<?php echo $cart_details['orginal_price']; ?>" />
                        </tr>
                        </tbody>

                        <tfoot>
                        <tr class="cart-subtotal">
                            <th>Subtotal:</th>
                            <td><span class="checkout-Price-amount amount"><span class="checkout-Price-currencySymbol">£</span><?php echo $cart_details['price']; ?></span></td>
							<input type="hidden" name="product_subtotal[]" value="<?php echo $cart_details['price']; ?>" />
                        </tr>

                        <tr class="order-total">
                            <th>Total:</th>
                            <td><strong><span class="checkout-Price-amount amount"><span class="checkout-Price-currencySymbol">£</span><?php echo $cart_details['price']; ?></span></strong></td>
							<input type="hidden" name="product_total[]" value="<?php echo $cart_details['price']; ?>" />
                        </tr>
                        </tfoot>
                    </table>
				
                <?php }
				if(!empty($basketid)){ 
				$implode_basket_id=implode(',',$basketid);
				?>
                <input type="hidden" name="basket_id" value="<?php echo $implode_basket_id; ?>" />
				 <?php }} ?>	
                    <div id="payment" class="checkout-checkout-payment" style="background:none;">
 
                        <div class="form-row place-order"> <input type="submit" class="button alt" name="checkout_checkout_place_order"
						id="place_order" value="Proceed to Order Place" data-value="Place order" style="float:left;"></div>
                    </div>
                </div> <!--order_review-->
            </form><!--checkout checkout-checkout-->
        </div>
    </main>
</div>