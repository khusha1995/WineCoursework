<?php
  class Login 
  {
    public $id;
   

    public function __construct() 
    {
	
		 if(isset($_POST['user_id']) && $_POST['user_id'] != NULL && isset($_POST['password']) && $_POST['password'] != NULL)
		{
			 $db = Db::getInstance();
			 $userrow=0;
			 $query_user_login = "SELECT * FROM admin_details WHERE `user_name`='".$_POST['user_id']."' AND `password`='".md5($_POST['password'])."'";
			 foreach($db->query($query_user_login) as $userdata){
				$userrow=1;
				 $_SESSION['user_name']=$userdata['user_name'];
				 $_SESSION['email_id']=$userdata['email_id'];
				 $_SESSION['id']=$userdata['id'];
				
				 
			 }
			

			 if($userrow==1)
			 {
				 redirectto_other_page(BASE_URL);
			 }
			 else
			 {
                set_error_message("Login Details Is invalid");
			 }
		}
    }
  }
  
  $LOGIN =  new Login();
?>