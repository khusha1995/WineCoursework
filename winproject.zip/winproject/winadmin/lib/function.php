<?php 
function  set_error_message($error)
{
	$_SESSION['error_message']=$error;
}

//error message incase anything wrong occures
function  error_display()
{
   $error_message=$_SESSION['error_message'];
   unset($_SESSION['error_message']);
   return $error_message;
}


function userlogin_checking()
{
	global $action,$controller;
    if($_SESSION['user_name'] ==  NULL ||  $_SESSION['id'] ==  NULL){
		 $controller = 'pages';
         $action     = 'login';
	}
}

//check whether user is logged in
function is_userlogin()
{
    if($_SESSION['user_name'] ==  NULL ||  $_SESSION['id'] ==  NULL){
       return 0;
	}
	return 1;
}


function redirectto_other_page($url)
{
 global $action,$controller;
 $action="";
 $controller="";

header('Location:'.$url);
exit;
}


function create_product_slug($slug)
{
	 $db = Db::getInstance();
	 $query_category = "SELECT * FROM wines  where wine_name='".$slug."'";	
	 $resule_cat=$db->prepare($query_category);
	 $resule_cat->execute();
	 $count = $resule_cat->rowCount();
	 $slug=str_replace(" ","_",$slug);
	if($count==0)
	{
		return $slug;
	}else
	{
		$count=$count+1;
		$slug=$slug."_".uniqid(); 
		return $slug;
	} 
 exit;
}
