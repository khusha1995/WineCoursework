<?php

class Wineusers 
{
    public $resule_cat;
    public function __construct() 
	{
        $this->db = Db::getInstance();
    }

    public function insert()
	{
		//user login to ensure that user is logged in before continuing
        $user_id = $_POST['user_id'];
        $password = md5($_POST['password']);
        $query_category = "SELECT * FROM customer where username='".$user_id."' and password='".$password."'";

        //$query_category = "SELECT * FROM customer";
        $this->resule_cat=$this->db->prepare($query_category);
        $this->resule_cat->execute();
        $this->resule_cat = $this->resule_cat->fetchAll();

        if(!empty($this->resule_cat))
		{
            //session_start();
            $_SESSION['users'] = $this->resule_cat;
            return true;
        }else
		{
            return false;
        }
    }

	//store whatever data is in the card into the database  //acts as a type of wishlist or list for later viewing.
    public function StoreDataToCart(){
		//store cart data
        $flg=2; $i=0;
        if(isset($_SESSION['cart']))
		{
            foreach($_SESSION['cart'] as $cart_row)
			{
		//make sure use is logged in firstly
                if(isset($_SESSION['users']))
				{
		//get the query
                    $get_query = " 
                        select * 
                        from shopping_basket
                        where unique_wine_code='".$cart_row['id']."'";
                    $get_query=$this->db->prepare($get_query);
                    $get_query->execute();
                    $get_query = $get_query->fetchAll();
		//if there is nothing in the query, insert instead. insert into shopping_basket = shoppingbasket id, unique wine code, username, quantity, cost, total
                    if(empty($get_query))
					{
                        $sql = "INSERT INTO shopping_basket (shopping_basket_id, unique_wine_code, username,quantity_available_id,cost_of_wine_id,total)
                                VALUES ('".$cart_row['shopping_basket_id']."',".$cart_row['unique_wine_code'].",'".$_SESSION['users'][0]['username']."','".$cart_row['qty']."','".$cart_row['cost_of_wine_id']."',".$cart_row['price'].")";
                    }else
					{
		//else we're updating the basket if it is not empty
                        $qty = $cart_row['qty']+$get_query[0]['quantity_available_id'];
                        $total = $cart_row['price']+$get_query[0]['total'];
                        echo $sql = "Update shopping_basket set quantity_available_id='".$qty."',total=".$total."
                        WHERE unique_wine_code=".$cart_row['unique_wine_code']." AND username = '".$_SESSION['users'][0]['username']."' AND cost_of_wine_id = '".$cart_row['cost_of_wine_id']."'";
                    }

                    if($this->db->exec($sql))
					{
                      //  die('success');
                    }else{
                       // die('fail');
                    }
                    //var_dump($get_query,$this->db->exec($sql));
                    //die;
                }
                $flg = 1;
            }
            $i++;
        }
    }



    public function UpdateCartData()
	{
		//update cart data	
        if(isset($_SESSION['users']))
		{
            $i=0;
	//create forloop that goes over shopping basket
            foreach ($_POST['shopping_basket_id'] as $shopping_basket_id)
			{		
    //calculate productprice by using = cost*quantity			
					$product_price = $_POST['cost_of_wine'][$i] * $_POST['qty'][$i];
	//then set quantity available with the total product price
					//echo $product_price; exit;
                $sql = "Update shopping_basket set quantity_available_id='".$_POST['qty'][$i]."',total='".$product_price."'
                        WHERE shopping_basket_id='".$shopping_basket_id."' AND unique_wine_code ='".$_POST['unique_wine_code'][$i]."' AND username = '".$_SESSION['users'][0]['username']."'";
             $this->db->exec($sql);
                $i++;
            }

            return true;

        }else
		{
            foreach($_SESSION['cart'] as $cart_row)
			{
                $i=0;
                foreach ($_POST['shopping_basket_id'] as $shopping_basket_id)
				{
                    if($cart_row['shopping_basket_id'] == $shopping_basket_id)
					{
                        $_SESSION['cart'][$i]['qty']=$_POST['qty'][$i];
                        $_SESSION['cart'][$i]['price']=$_SESSION['cart'][$i]['orginal_price'] * $_POST['qty'][$i];
                        $flg = 1;
                    }
                    $i++;
                }
            }
            return true;
        }
    }
}