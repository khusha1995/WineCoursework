<?php
class CategoryController {
    public function view() 
    {
      //get detail of product category
	  $category_dsp_page=new View_category_dsp_detailpage();
	  
	  //user view -> detail of product category are needed 
	  require_once('views/product/product_category.php');
    }
}
?>