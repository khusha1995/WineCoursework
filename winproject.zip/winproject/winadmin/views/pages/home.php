<?php $item_per_page=5; $pages = ceil($List_product->results[0][0]/$item_per_page); ?>      
      <!--main content start-->
      <section id="main-content">
          <section class="wrapper">
          	
				<!-- row -->
              <div class="row mt">
                  <div class="col-md-12">
                      <div class="content-panel">
                          		<div id="results"></div>
                              	<div class="paging_link"></div>
                      </div>
                  </div>
              </div><!-- /row -->

		</section>
      </section>
      <!--main content end-->
	  
	  
	  
<script type="text/javascript" src="<?php echo BASE_URL; ?>views/assets/js/custom-ajax.js"></script> 
<script type="text/javascript">
jQuery(document).ready(function() {
 jQuery("#results").load("<?php echo BASE_URL; ?>views/pages/get_records.php");  //initial page number to load
 jQuery(".paging_link").bootpag({
    total: <?php echo $pages; ?>
 }).on("page", function(e, num){
  e.preventDefault();
  jQuery("#results").load("<?php echo BASE_URL; ?>views/pages/get_records.php", {'page':num});
 });

});
</script>