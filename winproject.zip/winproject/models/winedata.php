<?php
class View_category_dsp_detailpage
{
	//get category ID with all category details this class is used in the models>product.php & views/product/product_category page.
	public $resule_cat_dsp_detailpage;
    public function __construct() 
	{
       $db = Db::getInstance();
	   //split URL paths into segments
	   global $expload_url;
	   $slug_name=CONTROLLER_POSTION+4; 
		
	 $query_category = "SELECT * FROM wine_category where category_name='".$expload_url[$slug_name]."'";	
		$this->resule_cat_dsp_detailpage=$db->prepare($query_category);
		$this->resule_cat_dsp_detailpage->execute();
		$this->resule_cat_dsp_detailpage = $this->resule_cat_dsp_detailpage->fetchAll();
    }
}
?>
