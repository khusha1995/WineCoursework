<?php
  function call($controller, $action) 
  {
    require_once('controllers/' . $controller . '_controller.php');
    switch($controller) 
	{
      case 'pages':
	    if($action=='login')			//if the user wants to login then show the login page
		{
			//make sure you include the login page lol
		 require_once('models/login.php');
		}else
		{
			//include the product list page 
		  require_once('models/product/list_product.php'); 
		}     
      break;
	  case 'product': 
			//if the user wants to view the products then show the product page which has the option to add/delete/update product wines
	       require_once('models/product/form_product.php');  
      break;
    }
	
	//'ucfirst' changes the first letter in a string to uppercase
	$controller=ucfirst($controller);
	$controller=$controller."Controller";
	
    $controller = new $controller();
    $controller->
	{ 
		$action 
	}();
  }

  // we're adding an entry for the new controller and its actions
  $controllers = array('pages' => ['home','login','error'],
					    'product' => ['add_form','insert_product','delete_product','update_product']
					   );

  if (array_key_exists($controller, $controllers)) 
  { 
    if (in_array($action, $controllers[$controller])) 
	{
		//call the controller and action
      call($controller, $action);
    } else {
		//else just call the error page in views >pages>error
      call('pages', 'error');
    }
  } else {
    call('pages', 'error');
  }
?>