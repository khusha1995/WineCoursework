<div class="footer">
   	  <div class="wrap">	
	     <div class="section group">
				<div class="col_1_of_4 span_1_of_4">
						<h4>Information</h4>
						<ul>
						<li><a href="#">Placeholder</a></li>
						<li><a href="#">Placeholder</a></li>
						</ul>
					</div>
				<div class="col_1_of_4 span_1_of_4">
					<h4>Why Choose Us?</h4>
						<ul>
						<li><a href="#">Placeholder</a></li>
						<li><a href="#">Placeholder</a></li>
						</ul>
				</div>
				<div class="col_1_of_4 span_1_of_4">
					<h4>*Something else here*</h4>
						<ul>
							<li><a href="#">Placeholder</a></li>
							<li><a href="#">Placeholder</a></li>
							<li><a href="#">Placeholder</a></li>
						</ul>
				</div>
				<div class="col_1_of_4 span_1_of_4">
					<h4>Contact The Team</h4>
						<ul>
							<li><span>03837629198</span></li>
						</ul>
				</div>
			</div>			
        </div>
        <div class="copy_right">
				<p>Daniel &amp; Khushal </p>
		   </div>
    </div>