<div class="header_slide">
			<div class="header_bottom_left">				
				<div class="categories">
				  <ul>
				  	<h3>Product Categories</h3>	
				     <li><a href="<?php echo BASE_URL; ?>getredwine/getredwine/Red_Wine">Red Wine</a></li>
				      <li><a href="<?php echo BASE_URL; ?>getredwine/getredwine/White_Wine">White Wine</a></li>
				      <li><a href="<?php echo BASE_URL; ?>getredwine/getredwine/Rosa_Wine">Rose Wine</a></li>
				  </ul>
				</div>					
	  	     </div>
		   <div class="clear"></div>
<div class="main">
    <div class="content">
    	<div class="section group">
				<div class="col_1_of_3 span_1_of_3">
					<h3>Welcome to 10 Green Bottles!</h3>
					<p>Welcome to the new 10 Green Bottles website, with the ever-growing expansion of technology we have decided to join in and make it possible for customers to now buy wines directly from our website. Making it even easier to find the perfect wine for you, quickly and securly.</p>
				</div>
				<div class="col span_1_of_3">
					
					    	  <div class="css-carousal"> 
							   	 <img src="<?php echo BASE_URL; ?>views/images/wine1.jpg" alt ="3 wine glasses cheering with each other red, white and rose" class = "css-img">
							   	 <img src="<?php echo BASE_URL; ?>views/images/wine2.jpg" alt ="2 wine glasses cheering with each other red and white wine" class = "css-img">
							   	 <img src="<?php echo BASE_URL; ?>views/images/wine3.jpg" alt ="4 wine glasses filled with a small amount of wine from different categories" class = "css-img">
							  </div>
				</div>
		</div>
    </div>
 </div>
 
 
<?php 
 if(!empty($search->resule_cat1)){ ?>
<div class="main">
    <div class="content">
                                                                    <!--PRODUCT THAT IS DISPLAYED WHEN SEARCHED FOR-->
    <?php foreach($search->resule_cat1 as $search_data){ ?>
	      <div class="section group">
			<div class="grid_1_of_4 images_1_of_4">
					 <a href="<?php echo BASE_URL; ?>product/<?php echo $search_data['slug']; ?>">
                         <img src="<?php echo BASE_URL; ?>views/product_images/<?php echo $search_data['wineimage']; ?>" alt="desired bottle from the search function"></a>		<!--MAKE SURE IMAGE DIMENSION = 212 x 212 -->
					 <h2><?php $slug=str_replace("_"," ",$search_data['wine_name']); echo $slug; ?></h2>
					 
					<div class="price-details">
				       <div class="price-number">
							<p><span class="pounds">£<?php echo $search_data['cost_of_wine']; ?></span></p>
					    </div>
					       		<div class="add-cart">								
									<h4><a data-unique_wine_code="<?php echo $search_data['unique_wine_code']; ?>" class="add-product" href="<?php echo BASE_URL; ?>/product/<?php echo $search_data['wine_name']; ?>">Add</a></h4>
							     </div>
							 <div class="clear"></div>
					</div>
					 
				</div>	
			</div>
			<?php } ?>			
    </div>
 </div>

<?php }elseif(!empty($view_category_dsp_home->resule_cat_dsp_home)){ ?>
<div class="main">
    <div class="content">
    <?php foreach($view_category_dsp_home->resule_cat_dsp_home as $dsp_cat_data){  ?>
	      <div class="section group">
          	<?php  $cat_id=$dsp_cat_data['category_name']; display_product($cat_id); ?>
			</div>
			<?php } ?>			
    </div>
 </div>
 <?php }else{ ?>
 <p><br><br></p>
 <p>Ah' sorry, there are no products that match your search! Try again!</p>
 <p><br><br><br><br><br><br><br><br><br><br><br><br><br></p>
 <?php } ?>