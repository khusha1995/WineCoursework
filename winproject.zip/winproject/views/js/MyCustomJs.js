/**
 * Created by Admin on 0008, Mar 8.
 */
var base_url = window.location.origin;
$(document).ready(function () {			//add product code
    $(".add-product").click(function (e) {
        e.preventDefault();
        $this = $(this);
        var unique_wine_code =  $this.data('unique_wine_code');
            $.ajax({
                type: "POST",
                url: base_url+"/winproject/lib/function.php",
                data: { unique_wine_code: unique_wine_code,cart:"cart" }
            }).done(function( msg ) {
                var msg= JSON.parse(msg);
                var str='';
                var total_price = 0;
                if(msg != ""){
                for(var i=0;i<msg.length;i++){
                    str+='<li><div style="width:100%"><div style="width:50%;"><img src="'+base_url+'/winproject/views/product_images/'+msg[i]['item_image']+'" alt=""></div><div style="width:50%;"></div><p>Item : '+msg[i]['name']+'</p><br><p>qty  : '+msg[i]['qty']+'</p><br><p>price : £'+msg[i]['price']+'</p><br><hr></div></li>';
                    total_price+=parseFloat(msg[i]['price']);
                }

                $(".cart-table-data,.cart-item-price").empty();
                $(".cart-item-price").html( msg.length +"item(s) - £"+total_price.toFixed(2));
                $(".cartTableData").html(str);
                alert("Product has been added to cart");
                }
            });
    });
  

    $(".remove-clart-item").click(function () {		//remove product

            $this = $(this);
            var product_id =  $this.data('product_id');
            $.ajax({
                type: "POST",
                url: base_url+"/winproject/lib/function.php",
                data: { cart_item_remove: product_id }
            }).done(function( msg ) {
                var msg= JSON.parse(msg);
                var total_price = 0;
                var str=0;
                if(msg.success=="true"){
                    var data = msg.data;
                    $(".cart-table-data,.cart-item-price").html("");
                    for(var i=0;i<data.length;i++){
                        str+='<li><div style="width:100%"><div style="width:50%;"><img src="'+base_url+'/winproject/views/product_images/'+data[i]['item_image']+'" alt=""></div><div style="width:50%;"></div><p>Item : '+data[i]['name']+'</p><br><p>qty  : '+data[i]['qty']+'</p><br><p>price : £'+data[i]['price']+'</p><br><hr></div></li>';
                        total_price+=parseFloat(data[i]['price']);
                    }
                    $(".cart-item-price").append( data.length +"item(s) - £"+total_price.toFixed(2));
                    $(".cartTableData").html(str);
                    $this.parent().parent().remove();
                    alert("Product deleted");
                }

            });
    });


    $(document).ready(function () {
        $(".showlogin").click(function () {
            $('.login').toggle();
        });
    });

});
