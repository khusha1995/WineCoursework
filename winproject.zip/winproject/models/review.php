<?php
class Review
{
	public function __construct()
	{
		if(isset($_POST['review']))
		{
			//insert user review into DB
				$db = Db::getInstance();
			$qry="INSERT INTO product_review (`product_id`,`username`,`review`)VALUES('".$_POST['product_id']."','".$_POST['username']."','".$_POST['userreview']."')"; 
			$db->query($qry); 
			header("Location:".BASE_URL."product/".$_POST['slug']."");
		}
	}
}
?>