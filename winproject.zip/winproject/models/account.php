<?php
class Order_details
{
	//get order details all data using queries from DB for user
	public $order_product_details;
	public function __construct() 
	{
		$db = Db::getInstance();
		$get_query = "SELECT * from order_history where username = '".$_SESSION['users'][0]['username']."'";
		$get_query=$db->prepare($get_query);
		$get_query->execute();
	 	$get_query = $get_query->fetchAll();
		foreach($get_query as $history_data)
		{
			if($history_data['shopping_basket_id'] != "")
			{
				$history_data_rpl=str_replace(",","','", $history_data['shopping_basket_id']);
				//SELECT distinct = only select unique occurances
				//INNER JOIN = select records that have matching values in BOTH tables
				$order_product_details=
				"SELECT distinct  shopping_basket.unique_wine_code, shopping_basket.quantity_available_id, 		   shopping_basket.total, order_date.order_date,wines.wine_name,cost_of_wine.cost_of_wine
				FROM order_history
				INNER JOIN shopping_basket ON shopping_basket.shopping_basket_id
				IN ('".$history_data_rpl."')
				INNER JOIN order_date ON order_history.order_date_id = order_date.order_date_id
				INNER JOIN wines ON shopping_basket.unique_wine_code = wines.unique_wine_code
				INNER JOIN cost_of_wine ON shopping_basket.cost_of_wine_id = cost_of_wine.cost_of_wine_id";
				$this->order_product_details=$db->prepare($order_product_details);
				$this->order_product_details->execute();
	 			$this->order_product_details = $this->order_product_details->fetchAll();
			}
		}
	}
}


class Acoount_details
{
	//get user account details
	public $account_details;
	public function __construct() {
		$db = Db::getInstance();
		$account_details1 = "SELECT * from customer where username = '".$_SESSION['users'][0]['username']."'";
		$this->account_details=$db->prepare($account_details1);
		$this->account_details->execute();
	 	$this->account_details = $this->account_details->fetchAll();
		//use fetchAll, it returns an array containing all results 
	}
}
?>